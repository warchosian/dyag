"""
RAG Commands module.
Contains all RAG-related command implementations.
"""

from dyag.rag.commands.prepare_rag import register_prepare_rag_command
from dyag.rag.commands.evaluate_rag import register_evaluate_rag_command
from dyag.rag.commands.compare_rag import register_compare_rag_command
from dyag.rag.commands.index_rag import register_index_rag_command
from dyag.rag.commands.query_rag import register_query_rag_command
from dyag.rag.commands.markdown_to_rag import register_markdown_to_rag_command
from dyag.rag.commands.test_rag import register_test_rag_command
from dyag.rag.commands.stats_rag import register_rag_stats_command

__all__ = [
    "register_prepare_rag_command",
    "register_evaluate_rag_command",
    "register_compare_rag_command",
    "register_index_rag_command",
    "register_query_rag_command",
    "register_markdown_to_rag_command",
    "register_test_rag_command",
    "register_rag_stats_command",
]
