"""
Module Park - DYAG

Transformation et manipulation de données structurées du référentiel Park.
"""

# Les commandes sont dans le sous-module commands
# Usage: from dyag.park.commands.json2md_park import convert_park_to_markdown
