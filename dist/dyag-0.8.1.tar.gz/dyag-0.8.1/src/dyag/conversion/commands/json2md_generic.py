"""
Generic JSON to Markdown converter using mdutils.

This module provides a generic approach to convert any JSON structure to Markdown,
automatically detecting and formatting different data types.

Example:
    dyag json2md input.json -o output.md --verbose
"""

import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional
from mdutils.mdutils import MdUtils


def json_to_markdown_generic(data: Any, md: MdUtils, level: int = 1, max_depth: int = 4) -> None:
    """
    Recursively convert JSON data to Markdown.

    Args:
        data: JSON data (dict, list, str, int, etc.)
        md: MdUtils instance for building Markdown
        level: Current heading level
        max_depth: Maximum nesting depth for headers
    """
    # Limit recursion depth to avoid mdutils bugs
    if level > max_depth:
        # Use bold text instead of headers for deep nesting
        if isinstance(data, dict):
            for key, value in data.items():
                md.new_paragraph(f"**{str(key).replace('_', ' ').title()}**: {str(value)[:100]}")
        else:
            md.new_paragraph(str(data)[:200])
        return

    if isinstance(data, dict):
        for key, value in data.items():
            # Create heading for key (limit to level 3 to avoid mdutils bugs)
            if level <= 3:
                md.new_header(level=level, title=str(key).replace('_', ' ').title())
            else:
                md.new_paragraph(f"**{str(key).replace('_', ' ').title()}**")

            # Process value based on type
            if isinstance(value, dict):
                json_to_markdown_generic(value, md, level + 1, max_depth)
            elif isinstance(value, list):
                if value and isinstance(value[0], dict):
                    # List of objects - create a structured view
                    for i, item in enumerate(value):
                        if len(value) > 1 and level <= 2:
                            md.new_paragraph(f"*Item {i + 1}*")
                        json_to_markdown_generic(item, md, level + 1, max_depth)
                elif value:
                    # List of primitives - create bullet list
                    md.new_list([str(v) for v in value])
                else:
                    md.new_paragraph("*(empty list)*")
            elif value is None or value == "":
                md.new_paragraph("*N/A*")
            elif isinstance(value, bool):
                md.new_paragraph(f"**{'Oui' if value else 'Non'}**")
            elif isinstance(value, (int, float)):
                md.new_paragraph(f"`{value}`")
            else:
                # String value - handle multiline text
                text = str(value).strip()
                if '\n' in text or '\r' in text:
                    # Multiline text
                    lines = text.replace('\r\n', '\n').replace('\r', '\n').split('\n')
                    for line in lines:
                        if line.strip():
                            md.new_paragraph(line.strip())
                else:
                    md.new_paragraph(text)

    elif isinstance(data, list):
        if data and isinstance(data[0], dict):
            # List of dictionaries at root level
            for i, item in enumerate(data):
                # Use 'name' or 'nom' or 'id' as title if available
                title = None
                for key in ['name', 'nom', 'Name', 'Nom', 'title', 'Title', 'id', 'Id', 'ID']:
                    if key in item:
                        title = str(item[key])
                        break

                if title:
                    md.new_header(level=level, title=f"{title}")
                else:
                    md.new_header(level=level, title=f"Item {i + 1}")

                json_to_markdown_generic(item, md, level + 1)

                # Add separator between items
                if i < len(data) - 1:
                    md.new_paragraph("---")
        else:
            # List of primitives
            md.new_list([str(v) for v in data])

    else:
        # Primitive value at root
        md.new_paragraph(str(data))


def convert_json_to_markdown_generic(
    json_content: str,
    output_path: Path,
    title: str = "JSON Document",
    verbose: bool = False
) -> bool:
    """
    Convert JSON content to Markdown file using generic approach.

    Args:
        json_content: JSON string
        output_path: Path to output Markdown file
        title: Document title
        verbose: Print progress info

    Returns:
        True if successful, False otherwise
    """
    try:
        # Parse JSON
        data = json.loads(json_content)

        if verbose:
            print(f"[INFO] Parsed JSON successfully")

        # Create MdUtils instance
        md = MdUtils(
            file_name=str(output_path.with_suffix('')),  # mdutils adds .md
            title=title
        )

        # Add metadata
        if isinstance(data, dict) and "applicationsia mini" in {k.lower() for k in data.keys()}:
            # Special handling for applications data
            for key in data:
                if key.lower() in ["applicationsia mini", "applications"]:
                    apps = data[key]
                    if isinstance(apps, list):
                        md.new_paragraph(f"**Nombre d'applications**: {len(apps)}")
                        md.new_paragraph("---")

                        if verbose:
                            print(f"[INFO] Converting {len(apps)} applications...")

                        json_to_markdown_generic(apps, md, level=1)
                    break
        else:
            # Generic JSON structure
            json_to_markdown_generic(data, md, level=1)

        # Write file
        md.create_md_file()

        if verbose:
            print(f"[INFO] Markdown file created successfully")

        return True

    except json.JSONDecodeError as e:
        print(f"[ERROR] Invalid JSON: {e}", file=sys.stderr)
        return False
    except Exception as e:
        print(f"[ERROR] Conversion failed: {e}", file=sys.stderr)
        if verbose:
            import traceback
            traceback.print_exc()
        return False


def process_json_to_markdown_generic(
    input_file: str,
    output_file: Optional[str] = None,
    title: Optional[str] = None,
    verbose: bool = False
) -> int:
    """
    Process JSON file to Markdown using generic converter.

    Args:
        input_file: Path to input JSON file
        output_file: Path to output Markdown file (optional)
        title: Document title (optional, defaults to filename)
        verbose: Show detailed progress

    Returns:
        Exit code (0 for success, 1 for error)
    """
    input_path = Path(input_file)

    if not input_path.exists():
        print(f"Error: '{input_file}' does not exist.", file=sys.stderr)
        return 1

    if not input_path.is_file():
        print(f"Error: '{input_file}' is not a file.", file=sys.stderr)
        return 1

    # Determine output path
    if output_file is None:
        output_path = input_path.with_suffix('.md')
    else:
        output_path = Path(output_file)

    # Determine title
    if title is None:
        title = input_path.stem.replace('_', ' ').title()

    if verbose:
        print(f"[INFO] Converting JSON to Markdown (generic)...")
        print(f"[INFO] Input:  {input_path}")
        print(f"[INFO] Output: {output_path}")
        print(f"[INFO] Title:  {title}")

    try:
        # Read JSON file
        with open(input_path, 'r', encoding='utf-8') as f:
            json_content = f.read()

        if verbose:
            print(f"[INFO] Read {len(json_content)} characters from {input_path}")

        # Convert to Markdown
        success = convert_json_to_markdown_generic(
            json_content,
            output_path,
            title,
            verbose
        )

        if not success:
            print("[WARNING] Conversion produced no result", file=sys.stderr)
            return 1

        print(f"[SUCCESS] Markdown file created: {output_path}")
        return 0

    except Exception as e:
        print(f"Error: Conversion failed: {e}", file=sys.stderr)
        if verbose:
            import traceback
            traceback.print_exc()
        return 1


def register_json2md_command(subparsers):
    """Register the json2md command."""
    parser = subparsers.add_parser(
        'json2md',
        help='Convert JSON to Markdown (generic)',
        description='Convert any JSON file to Markdown format using generic structure detection.'
    )

    parser.add_argument(
        'input_file',
        type=str,
        help='Input JSON file path'
    )

    parser.add_argument(
        '-o', '--output',
        type=str,
        default=None,
        help='Output Markdown file path (default: input file with .md extension)'
    )

    parser.add_argument(
        '-t', '--title',
        type=str,
        default=None,
        help='Document title (default: derived from filename)'
    )

    parser.add_argument(
        '--verbose',
        action='store_true',
        help='Show detailed progress'
    )

    parser.set_defaults(func=lambda args: process_json_to_markdown_generic(
        args.input_file,
        args.output,
        args.title,
        args.verbose
    ))
