#!/usr/bin/env python3
"""
Main entry point for dyag application.
"""

import os
# Configurer HF_HOME avant d'importer les commandes RAG
# (remplace l'ancien TRANSFORMERS_CACHE qui est déprécié)
if 'TRANSFORMERS_CACHE' in os.environ and 'HF_HOME' not in os.environ:
    os.environ['HF_HOME'] = os.environ['TRANSFORMERS_CACHE']

import argparse
import sys

from dyag import __version__
from dyag.commands import (
    register_img2pdf_command,
    register_compresspdf_command,
    register_md2html_command,
    register_html2md_command,
    register_concat_html_command,
    register_add_toc4md_command,
    register_add_toc4html_command,
    register_html2pdf_command,
    register_project2md_command,
    register_md2project_command,
    register_make_interactive_command,
    register_flatten_wikisi_command,
    register_flatten_md_command,
    register_flatten_html_command,
    register_merge_md_command,
    register_merge_html_command,
    register_analyze_training_command,
    register_prepare_rag_command,
    register_evaluate_rag_command,
    register_compare_rag_command,
    register_index_rag_command,
    register_query_rag_command,
    register_markdown_to_rag_command,
    register_test_rag_command,
    register_rag_stats_command,
    register_show_evaluation_command,
    register_compare_evaluations_command,
    register_json2md_command,
    register_parkjson2md_command,
    register_parkjson2json_command,
    register_json2jsonl_command,
    register_generate_questions_command,
    register_generate_evaluation_report_command,
    register_merge_evaluation_command,
    register_analyze_evaluation_command,
    register_web_server_command,
    register_chk_utf8_command,
    register_fix_utf8_command
)

# Fine-tuning commands
from dyag.finetuning.commands import (
    register_generate_training_command,
    register_finetune_command,
    register_query_finetuned_command,
    register_evaluate_finetuned_command,
    register_compare_models_command,
    register_export_to_gguf_command
)


def create_parser():
    """Create and configure the argument parser."""
    parser = argparse.ArgumentParser(
        prog="dyag",
        description="Dyag - Outil de manipulation de fichiers et conversion",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )

    parser.add_argument(
        "-v", "--version",
        action="version",
        version=f"dyag {__version__}"
    )

    # Create subparsers for commands
    subparsers = parser.add_subparsers(
        title="Commandes disponibles",
        description="Utilisez 'dyag <commande> -h' pour plus d'informations",
        dest="command",
        help="Commande à exécuter"
    )

    # Register commands
    register_img2pdf_command(subparsers)
    register_compresspdf_command(subparsers)
    register_md2html_command(subparsers)
    register_html2md_command(subparsers)
    register_concat_html_command(subparsers)
    register_add_toc4md_command(subparsers)
    register_add_toc4html_command(subparsers)
    register_html2pdf_command(subparsers)
    register_project2md_command(subparsers)
    register_md2project_command(subparsers)
    register_make_interactive_command(subparsers)
    register_flatten_wikisi_command(subparsers)
    register_flatten_md_command(subparsers)
    register_flatten_html_command(subparsers)
    register_merge_md_command(subparsers)
    register_merge_html_command(subparsers)
    register_analyze_training_command(subparsers)
    register_prepare_rag_command(subparsers)
    register_evaluate_rag_command(subparsers)
    register_compare_rag_command(subparsers)
    register_index_rag_command(subparsers)
    register_query_rag_command(subparsers)
    register_markdown_to_rag_command(subparsers)
    register_test_rag_command(subparsers)
    register_rag_stats_command(subparsers)
    register_show_evaluation_command(subparsers)
    register_compare_evaluations_command(subparsers)
    register_json2md_command(subparsers)
    register_parkjson2md_command(subparsers)
    register_parkjson2json_command(subparsers)
    register_json2jsonl_command(subparsers)
    register_generate_questions_command(subparsers)
    register_generate_evaluation_report_command(subparsers)
    register_merge_evaluation_command(subparsers)
    register_analyze_evaluation_command(subparsers)
    register_web_server_command(subparsers)

    # Encoding commands
    register_chk_utf8_command(subparsers)
    register_fix_utf8_command(subparsers)

    # Fine-tuning commands
    register_query_finetuned_command(subparsers)
    register_generate_training_command(subparsers)
    register_finetune_command(subparsers)
    register_evaluate_finetuned_command(subparsers)
    register_compare_models_command(subparsers)
    register_export_to_gguf_command(subparsers)

    return parser


def main():
    """Main function to handle command-line arguments and application logic."""
    parser = create_parser()
    args = parser.parse_args()

    # If no command is provided, show help
    if args.command is None:
        parser.print_help()
        return 0

    # Execute the command
    if hasattr(args, 'func'):
        return args.func(args)

    return 0


if __name__ == "__main__":
    sys.exit(main())
