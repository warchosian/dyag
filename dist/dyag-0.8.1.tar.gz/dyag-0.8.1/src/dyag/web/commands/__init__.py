"""Commandes web pour DYAG."""

from .web_server import register_web_server_command

__all__ = ["register_web_server_command"]
