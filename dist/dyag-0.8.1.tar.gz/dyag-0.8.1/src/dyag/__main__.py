"""
Entry point for running dyag as a module: python -m dyag
"""

from dyag.main import main

if __name__ == "__main__":
    main()
