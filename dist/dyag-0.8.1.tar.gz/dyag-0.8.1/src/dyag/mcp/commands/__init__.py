"""
Commandes MCP pour DYAG

Ce module contient les commandes liées au serveur MCP.
"""

from .test_mcp import main as test_mcp

__all__ = ["test_mcp"]
