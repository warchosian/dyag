"""Commandes de traitement de documents - DYAG"""

from .compress_pdf import compress_pdf

__all__ = ["compress_pdf"]
