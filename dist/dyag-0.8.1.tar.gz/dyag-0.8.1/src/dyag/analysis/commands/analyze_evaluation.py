#!/usr/bin/env python3
"""
Commande analyze-evaluation pour analyser les résultats d'évaluation RAG.

Fait partie du package dyag.
"""
import json
import sys
from pathlib import Path
from collections import defaultdict


def analyze_evaluation_results(results_file, detailed=False):
    """
    Analyse détaillée des résultats d'évaluation RAG.

    Args:
        results_file: Chemin vers fichier JSON de résultats
        detailed: Si True, affiche analyses détaillées

    Returns:
        True si succès, False si erreur
    """
    results_path = Path(results_file)
    if not results_path.exists():
        print(f"❌ File not found: {results_file}")
        return False

    print(f"\n{'='*70}")
    print(f"ANALYSE RÉSULTATS RAG - {results_path.name}")
    print(f"{'='*70}\n")

    # Charger données
    try:
        with open(results_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except Exception as e:
        print(f"❌ Error loading file: {e}")
        return False

    metadata = data.get('metadata', {})
    statistics = data.get('statistics', {})
    results = data.get('results', [])

    # === MÉTADONNÉES ===
    print("=== MÉTADONNÉES ===\n")
    print(f"Dataset: {metadata.get('dataset', 'N/A')}")
    print(f"Collection: {metadata.get('collection', 'N/A')}")
    print(f"Model: {metadata.get('model', 'N/A')}")
    print(f"Date: {metadata.get('date', 'N/A')}")
    print(f"n_chunks: {metadata.get('n_chunks', 'N/A')}")
    print(f"Reranking: {metadata.get('use_reranking', 'N/A')}")

    # === STATISTIQUES GLOBALES ===
    print(f"\n{'='*70}")
    print("=== STATISTIQUES GLOBALES ===\n")

    total = statistics.get('total', 0)
    successful = statistics.get('successful', 0)
    failed = statistics.get('failed', 0)
    success_rate = statistics.get('success_rate', 0.0)

    print(f"Questions testées: {total}")
    print(f"✓ Succès: {successful} ({success_rate:.1f}%)")
    print(f"✗ Échecs: {failed} ({100-success_rate:.1f}%)")

    if statistics.get('total_time'):
        total_time = statistics['total_time']
        avg_time = total_time / total if total > 0 else 0
        print(f"\nTemps total: {total_time:.1f}s ({total_time/3600:.1f}h)")
        print(f"Temps moyen: {avg_time:.1f}s/question")

    if statistics.get('total_tokens'):
        total_tokens = statistics['total_tokens']
        avg_tokens = total_tokens / total if total > 0 else 0
        print(f"\nTokens total: {total_tokens:,}")
        print(f"Tokens moyen: {avg_tokens:.0f}/question")

    # === PERFORMANCE PAR CATÉGORIE ===
    print(f"\n{'='*70}")
    print("=== PERFORMANCE PAR CATÉGORIE ===\n")

    by_category = defaultdict(lambda: {'total': 0, 'success': 0})
    for r in results:
        cat = r.get('category', 'unknown')
        by_category[cat]['total'] += 1
        if r.get('status') == 'success':
            by_category[cat]['success'] += 1

    # Afficher par catégorie
    print(f"{'Catégorie':<20} {'Score':<15} {'%':<10} {'Statut'}")
    print("-" * 70)

    for cat in sorted(by_category.keys()):
        stats = by_category[cat]
        pct = (stats['success'] / stats['total'] * 100) if stats['total'] > 0 else 0

        # Emoji statut
        if pct >= 95:
            status = "✅ Excellent"
        elif pct >= 80:
            status = "✅ Bon"
        elif pct >= 60:
            status = "⚠️ Moyen"
        else:
            status = "❌ Faible"

        score_str = f"{stats['success']}/{stats['total']}"
        print(f"{cat:<20} {score_str:<15} {pct:>5.1f}%    {status}")

    # === ANALYSE PAR APPLICATION ===
    if detailed and any('app_name' in r for r in results):
        print(f"\n{'='*70}")
        print("=== ANALYSE PAR APPLICATION ===\n")

        by_app = defaultdict(lambda: {'total': 0, 'success': 0})
        for r in results:
            app = r.get('app_name', 'unknown')
            by_app[app]['total'] += 1
            if r.get('status') == 'success':
                by_app[app]['success'] += 1

        # Applications totales
        total_apps = len(by_app)
        apps_100 = sum(1 for stats in by_app.values() if stats['success'] == stats['total'])
        apps_0 = sum(1 for stats in by_app.values() if stats['success'] == 0)

        print(f"Applications couvertes: {total_apps}")
        print(f"Applications 100%: {apps_100} ({apps_100/total_apps*100:.1f}%)")
        print(f"Applications 0%: {apps_0} ({apps_0/total_apps*100:.1f}%)")

        # Applications problématiques (<50%)
        problematic = []
        for app, stats in by_app.items():
            pct = (stats['success'] / stats['total'] * 100) if stats['total'] > 0 else 0
            if pct < 50:
                problematic.append((app, pct, stats))

        if problematic:
            print(f"\n--- Applications Problématiques (<50%) ---")
            print(f"Total: {len(problematic)} applications\n")
            print(f"{'Application':<35} {'Score':<10} {'%':<10}")
            print("-" * 70)

            for app, pct, stats in sorted(problematic, key=lambda x: x[1])[:20]:  # Top 20
                score_str = f"{stats['success']}/{stats['total']}"
                print(f"{app:<35} {score_str:<10} {pct:>5.1f}%")

    # === DISTRIBUTION SIMILARITÉ ===
    if detailed and any('similarity' in r for r in results):
        print(f"\n{'='*70}")
        print("=== DISTRIBUTION SIMILARITÉ ===\n")

        similarities = [r.get('similarity', 0) for r in results if 'similarity' in r]
        if similarities:
            similarities_sorted = sorted(similarities)
            n = len(similarities)

            print(f"Nombre de valeurs: {n}")
            print(f"Moyenne: {sum(similarities)/n:.3f}")
            print(f"Médiane: {similarities_sorted[n//2]:.3f}")
            print(f"Min: {min(similarities):.3f}")
            print(f"Max: {max(similarities):.3f}")

            # Distribution par tranches
            print("\n--- Distribution ---")
            bins = [(0.0, 0.2), (0.2, 0.4), (0.4, 0.6), (0.6, 0.8), (0.8, 1.0)]
            for low, high in bins:
                count = sum(1 for s in similarities if low <= s < high)
                pct = count / n * 100
                bar = "█" * int(pct / 2)
                print(f"{low:.1f}-{high:.1f}: {count:5} ({pct:5.1f}%) {bar}")

    # === ANALYSE TEMPORELLE ===
    if detailed and any('time' in r for r in results):
        print(f"\n{'='*70}")
        print("=== ANALYSE TEMPORELLE ===\n")

        times = [r.get('time', 0) for r in results if 'time' in r]
        if times:
            times_sorted = sorted(times)
            n = len(times)

            print(f"Temps moyen: {sum(times)/n:.1f}s")
            print(f"Temps médian: {times_sorted[n//2]:.1f}s")
            print(f"Temps min: {min(times):.1f}s")
            print(f"Temps max: {max(times):.1f}s")

            # Temps par catégorie
            if any('category' in r for r in results):
                print("\n--- Temps Moyen par Catégorie ---\n")

                time_by_cat = defaultdict(list)
                for r in results:
                    if 'time' in r and 'category' in r:
                        cat = r['category']
                        time_by_cat[cat].append(r['time'])

                print(f"{'Catégorie':<20} {'Temps Moyen':<15} {'Min-Max'}")
                print("-" * 70)

                for cat in sorted(time_by_cat.keys()):
                    times_cat = time_by_cat[cat]
                    avg_time = sum(times_cat) / len(times_cat)
                    min_time = min(times_cat)
                    max_time = max(times_cat)
                    print(f"{cat:<20} {avg_time:>6.1f}s         {min_time:.1f}s - {max_time:.1f}s")

    # === TOP QUESTIONS ÉCHOUÉES ===
    if detailed:
        print(f"\n{'='*70}")
        print("=== TOP 10 QUESTIONS ÉCHOUÉES ===\n")

        failed_questions = [
            r for r in results
            if r.get('status') in ['fail', 'incorrect']
        ]

        if failed_questions:
            # Trier par similarité croissante
            failed_sorted = sorted(
                failed_questions,
                key=lambda x: x.get('similarity', 0)
            )[:10]

            for i, q in enumerate(failed_sorted, 1):
                question = q.get('question', 'N/A')
                expected = q.get('expected_answer', 'N/A')
                obtained = q.get('obtained_answer', 'N/A')
                similarity = q.get('similarity', 0)
                app_name = q.get('app_name', 'N/A')

                print(f"{i}. [{app_name}] {question[:60]}...")
                print(f"   Attendu: {expected[:60]}...")
                print(f"   Obtenu: {obtained[:60]}...")
                print(f"   Similarité: {similarity:.3f}\n")
        else:
            print("Aucune question échouée ✓")

    # === RECOMMANDATIONS ===
    print(f"\n{'='*70}")
    print("=== RECOMMANDATIONS ===\n")

    if success_rate >= 85:
        print("✅ Excellent score global (≥85%)")
        print("   → Système production-ready")
        print("   → Phase 2.6 Hybrid Search optionnelle")
    elif success_rate >= 70:
        print("✅ Bon score global (70-84%)")
        print("   → Identifier catégories faibles")
        print("   → Envisager Phase 2.6 Hybrid Search (+5-10%)")
    elif success_rate >= 60:
        print("⚠️ Score acceptable (60-69%)")
        print("   → Analyser causes racines des échecs")
        print("   → Recommandé: Phase 2.6 Hybrid Search")
    else:
        print("❌ Score insuffisant (<60%)")
        print("   → Vérifier qualité des chunks sources")
        print("   → Analyser prompt LLM")
        print("   → Obligatoire: Phase 2.6 Hybrid Search")

    # Recommandations par catégorie
    weak_categories = [(cat, by_category[cat]) for cat in by_category
                       if (by_category[cat]['success'] / by_category[cat]['total'] * 100) < 70]

    if weak_categories:
        print(f"\nCatégories faibles (<70%):")
        for cat, stats in weak_categories:
            pct = stats['success'] / stats['total'] * 100
            print(f"  - {cat}: {pct:.1f}%")
            if cat in ['description', 'descriptions']:
                print(f"    → Améliorer prompt pour réponses longues")
            elif cat in ['contact', 'contacts']:
                print(f"    → Vérifier présence contacts dans chunks")
            elif cat in ['date', 'dates', 'événements']:
                print(f"    → Vérifier extraction événements")

    print(f"\n{'='*70}\n")

    return True


def run_analyze_evaluation(args):
    """Point d'entrée pour la commande CLI."""
    return 0 if analyze_evaluation_results(args.results_file, detailed=args.detailed) else 1


def main():
    """Point d'entrée pour exécution standalone."""
    import argparse

    parser = argparse.ArgumentParser(
        description="Analyser les résultats d'évaluation RAG",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Simple analysis
  dyag analyze-evaluation evaluation/results_1008_full.json

  # Detailed analysis (with apps, top failures, distributions)
  dyag analyze-evaluation --detailed evaluation/results.json

  # Quick analysis
  dyag analyze-evaluation evaluation/results_test.json
        """
    )

    parser.add_argument(
        'results_file',
        help='JSON results file to analyze'
    )

    parser.add_argument(
        '--detailed', '-d',
        action='store_true',
        help='Show detailed analysis (apps, top failures, distributions)'
    )

    args = parser.parse_args()
    return run_analyze_evaluation(args)


if __name__ == "__main__":
    sys.exit(main())
