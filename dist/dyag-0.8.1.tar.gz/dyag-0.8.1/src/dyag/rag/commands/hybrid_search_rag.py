"""
Phase 2.6 - Hybrid Search (BM25 + Vector)
Combine lexical search (BM25) with semantic search (embeddings) for better retrieval.
"""
from typing import List, Dict, Any, Optional
import numpy as np
from rank_bm25 import BM25Okapi


class HybridSearcher:
    """
    Hybrid search combining BM25 (lexical) and vector similarity (semantic).
    """

    def __init__(self, chunks: List[Dict[str, Any]], alpha: float = 0.5):
        """
        Initialize hybrid searcher.

        Args:
            chunks: List of chunks with 'content' and 'embedding' fields
            alpha: Weight for BM25 vs vector (0=BM25 only, 1=vector only)
        """
        self.chunks = chunks
        self.alpha = alpha

        # Prepare BM25 corpus
        corpus = [chunk['content'].lower().split() for chunk in chunks]
        self.bm25 = BM25Okapi(corpus)

    def search(
        self,
        query: str,
        query_embedding: np.ndarray,
        top_k: int = 5
    ) -> List[Dict[str, Any]]:
        """
        Hybrid search: combine BM25 and vector similarity.

        Args:
            query: Text query
            query_embedding: Query embedding vector
            top_k: Number of results to return

        Returns:
            Top-k chunks sorted by hybrid score
        """
        # BM25 scores (lexical)
        bm25_scores = self.bm25.get_scores(query.lower().split())
        bm25_scores_norm = self._normalize_scores(bm25_scores)

        # Vector similarity scores (semantic)
        vector_scores = []
        for chunk in self.chunks:
            embedding = np.array(chunk.get('embedding', []))
            if len(embedding) == 0:
                vector_scores.append(0.0)
            else:
                # Cosine similarity
                similarity = np.dot(query_embedding, embedding) / (
                    np.linalg.norm(query_embedding) * np.linalg.norm(embedding)
                )
                vector_scores.append(similarity)

        vector_scores_norm = self._normalize_scores(np.array(vector_scores))

        # Combine scores
        hybrid_scores = (
            (1 - self.alpha) * bm25_scores_norm +
            self.alpha * vector_scores_norm
        )

        # Get top-k indices
        top_indices = np.argsort(hybrid_scores)[::-1][:top_k]

        # Return top chunks with scores
        results = []
        for idx in top_indices:
            chunk = self.chunks[idx].copy()
            chunk['hybrid_score'] = float(hybrid_scores[idx])
            chunk['bm25_score'] = float(bm25_scores_norm[idx])
            chunk['vector_score'] = float(vector_scores_norm[idx])
            results.append(chunk)

        return results

    def _normalize_scores(self, scores: np.ndarray) -> np.ndarray:
        """Normalize scores to [0, 1] range."""
        if len(scores) == 0 or scores.max() == scores.min():
            return np.zeros_like(scores)
        return (scores - scores.min()) / (scores.max() - scores.min())


def test_hybrid_search():
    """Test hybrid search functionality."""
    # Sample chunks
    chunks = [
        {
            'id': '1',
            'content': 'Python is a programming language',
            'embedding': np.random.rand(384)  # Dummy embedding
        },
        {
            'id': '2',
            'content': 'Java is also a programming language',
            'embedding': np.random.rand(384)
        },
        {
            'id': '3',
            'content': 'Machine learning with Python',
            'embedding': np.random.rand(384)
        }
    ]

    # Create searcher
    searcher = HybridSearcher(chunks, alpha=0.5)

    # Test query
    query = "Python programming"
    query_embedding = np.random.rand(384)

    results = searcher.search(query, query_embedding, top_k=2)

    print("Hybrid Search Results:")
    for i, result in enumerate(results, 1):
        print(f"{i}. {result['content']}")
        print(f"   Hybrid: {result['hybrid_score']:.3f} | "
              f"BM25: {result['bm25_score']:.3f} | "
              f"Vector: {result['vector_score']:.3f}")


if __name__ == '__main__':
    test_hybrid_search()
