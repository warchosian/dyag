"""
Commande pour afficher les résultats d'une évaluation existante.

Permet de visualiser les résultats sans réexécuter l'évaluation.
"""

import json
import sys
from pathlib import Path
from typing import Dict, List


def format_metadata(metadata: Dict) -> str:
    """Formate les métadonnées d'une évaluation."""
    lines = [
        "=" * 80,
        "METADONNEES DE L'EVALUATION",
        "=" * 80,
        f"Date: {metadata.get('timestamp', 'N/A')}",
        f"Modele LLM: {metadata.get('llm_model', 'N/A')}",
        f"Collection: {metadata.get('collection_name', 'N/A')}",
        f"Chunks: {metadata.get('n_chunks', 'N/A')}",
        f"Filtrage: {'Oui' if metadata.get('filtering_enabled', False) else 'Non'}",
        f"Reranking: {'Oui' if metadata.get('reranking_enabled', False) else 'Non'}",
        "",
        "RESULTATS GLOBAUX",
        "=" * 80,
        f"Questions totales: {metadata.get('total_questions', 0)}",
        f"  [OK] Succes: {metadata.get('successful', 0)}",
        f"  [ERR] Echecs: {metadata.get('failed', 0)}",
        "",
        "QUALITE DES REPONSES",
        f"  Reponses correctes (>=70%): {metadata.get('correct_answers', 0)} ({metadata.get('accuracy_percent', 0):.1f}%)",
        f"  Matchs exacts: {metadata.get('exact_matches', 0)}",
        f"  Similarite moyenne: {metadata.get('average_similarity', 0):.1%}",
        "",
        "PERFORMANCE",
        f"  Temps total: {metadata.get('total_time', 0):.1f}s ({metadata.get('total_time', 0)/60:.1f} min)",
        f"  Tokens total: {metadata.get('total_tokens', 0)}",
        "=" * 80,
    ]
    return "\n".join(lines)


def format_result(result: Dict, index: int, total: int) -> str:
    """Formate un résultat individuel."""
    question = result.get('question', 'N/A')
    answer = result.get('answer', 'N/A')
    expected = result.get('expected', 'N/A')
    similarity = result.get('similarity', 0)
    is_correct = result.get('is_correct', False)
    exact_match = result.get('exact_match', False)
    tokens = result.get('tokens', 0)
    time = result.get('time', 0)
    sources = result.get('sources', [])

    # Tronquer si trop long
    answer_display = answer[:200] + "..." if len(answer) > 200 else answer
    expected_display = expected[:100] + "..." if len(expected) > 100 else expected

    lines = [
        f"\n[{index}/{total}] {question}",
        "-" * 80,
        f"[RÉPONSE] {answer_display}",
        f"[ATTENDU] {expected_display}",
        f"[SIMILARITÉ] {similarity:.1%} | Correct: {is_correct} | Exact: {exact_match}",
        f"[PERF] {time:.1f}s, {tokens} tokens",
        f"[SOURCES] {', '.join(sources[:3])}{'...' if len(sources) > 3 else ''}",
        "-" * 80,
    ]
    return "\n".join(lines)


def show_evaluation(file_path: str, detailed: bool = False, limit: int = None):
    """
    Affiche les résultats d'une évaluation.

    Args:
        file_path: Chemin vers le fichier JSON de résultats
        detailed: Afficher les résultats question par question
        limit: Nombre max de résultats à afficher (None = tous)
    """
    path = Path(file_path)

    if not path.exists():
        print(f"[ERROR] Fichier introuvable: {file_path}")
        return 1

    # Charger les résultats
    print(f"[INFO] Chargement des résultats: {file_path}")
    with open(path, 'r', encoding='utf-8') as f:
        data = json.load(f)

    metadata = data.get('metadata', {})
    results = data.get('results', [])

    # Afficher métadonnées
    print("\n" + format_metadata(metadata))

    # Afficher résultats détaillés si demandé
    if detailed:
        print("\n")
        print("=" * 80)
        print("RÉSULTATS DÉTAILLÉS")
        print("=" * 80)

        total = len(results)
        display_results = results[:limit] if limit else results

        for i, result in enumerate(display_results, 1):
            print(format_result(result, i, total))

        if limit and len(results) > limit:
            print(f"\n[INFO] Affichage limité à {limit}/{total} résultats")
            print(f"       Utilisez --limit 0 pour tout afficher")

    print()
    return 0


def execute(args):
    """Exécute la commande show-evaluation."""
    return show_evaluation(
        file_path=args.file,
        detailed=args.detailed,
        limit=args.limit if args.limit > 0 else None
    )


def register_show_evaluation_command(subparsers):
    """Enregistre la commande show-evaluation."""
    parser = subparsers.add_parser(
        'show-evaluation',
        help='Affiche les résultats d\'une évaluation existante'
    )

    parser.add_argument(
        'file',
        type=str,
        help='Chemin vers le fichier JSON de résultats'
    )
    parser.add_argument(
        '-d', '--detailed',
        action='store_true',
        help='Afficher les résultats question par question'
    )
    parser.add_argument(
        '-l', '--limit',
        type=int,
        default=10,
        help='Nombre max de résultats détaillés à afficher (0 = tous, défaut: 10)'
    )

    parser.set_defaults(func=execute)
