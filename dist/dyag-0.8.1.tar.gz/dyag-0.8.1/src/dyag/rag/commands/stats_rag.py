"""
Commande rag-stats : Statistiques sur une collection RAG.

Ce module permet d'afficher des statistiques détaillées sur une collection ChromaDB.
Supporte trois formats de sortie : table, JSON, et Markdown.
"""

import os
# Configurer HF_HOME avant d'importer sentence_transformers
if 'TRANSFORMERS_CACHE' in os.environ and 'HF_HOME' not in os.environ:
    os.environ['HF_HOME'] = os.environ['TRANSFORMERS_CACHE']

import sys
import io
import json
import chromadb
from pathlib import Path
from typing import Dict, List
from collections import Counter
from datetime import datetime
import statistics

# Fixer l'encodage UTF-8 pour Windows
if sys.platform == 'win32' and __name__ == '__main__':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')


def get_directory_size(path: Path) -> float:
    """
    Calcule la taille d'un répertoire en MB.

    Args:
        path: Chemin vers le répertoire

    Returns:
        Taille en MB
    """
    total_size = 0
    for dirpath, dirnames, filenames in os.walk(path):
        for filename in filenames:
            filepath = os.path.join(dirpath, filename)
            if os.path.exists(filepath):
                total_size += os.path.getsize(filepath)
    return round(total_size / (1024 * 1024), 2)


def extract_keywords(texts: List[str], top_n: int = 10) -> List[Dict]:
    """
    Extrait les mots-clés les plus fréquents.

    Args:
        texts: Liste de textes
        top_n: Nombre de mots-clés à retourner

    Returns:
        Liste de {word, count}
    """
    # Mots courants à ignorer (stop words français)
    stop_words = {
        'le', 'la', 'les', 'un', 'une', 'des', 'de', 'du', 'et', 'ou',
        'mais', 'pour', 'dans', 'sur', 'avec', 'par', 'est', 'sont',
        'a', 'au', 'aux', 'ce', 'cette', 'ces', 'il', 'elle', 'on',
        'qui', 'que', 'quoi', 'dont', 'où', 'en', 'y', 'à', 'se', 'son',
        'sa', 'ses', 'leur', 'leurs', 'mon', 'ma', 'mes', 'ton', 'ta', 'tes',
        'notre', 'nos', 'votre', 'vos', 'nous', 'vous', 'ils', 'elles'
    }

    # Extraire tous les mots
    all_words = []
    for text in texts:
        words = text.lower().split()
        # Filtrer les mots courts et les stop words
        filtered_words = [
            w.strip('.,;:!?()[]{}"\'-')
            for w in words
            if len(w) > 3 and w.lower() not in stop_words
        ]
        all_words.extend(filtered_words)

    # Compter les occurrences
    word_counts = Counter(all_words)

    # Retourner les top N
    return [
        {'word': word, 'count': count}
        for word, count in word_counts.most_common(top_n)
    ]


def compute_stats(
    chroma_path: str,
    collection_name: str,
    detailed: bool = False
) -> Dict:
    """
    Calcule les statistiques d'une collection ChromaDB.

    Args:
        chroma_path: Chemin vers ChromaDB
        collection_name: Nom de la collection
        detailed: Inclure statistiques détaillées (plus lent)

    Returns:
        Dictionnaire de statistiques
    """
    # Connexion ChromaDB
    chroma_path_obj = Path(chroma_path)
    if not chroma_path_obj.exists():
        raise FileNotFoundError(f"ChromaDB introuvable: {chroma_path}")

    client = chromadb.PersistentClient(path=str(chroma_path_obj))

    try:
        collection = client.get_collection(collection_name)
    except Exception:
        raise ValueError(
            f"Collection '{collection_name}' non trouvee. "
            f"Collections disponibles: {[c.name for c in client.list_collections()]}"
        )

    # Récupérer tous les chunks
    total_chunks = collection.count()

    if total_chunks == 0:
        return {
            'collection': collection_name,
            'timestamp': datetime.now().isoformat(),
            'total_chunks': 0,
            'message': 'Collection vide'
        }

    # Récupérer un échantillon ou tous les chunks
    sample_size = min(total_chunks, 1000) if not detailed else total_chunks
    results = collection.get(limit=sample_size, include=['metadatas', 'documents'])

    # Statistiques de base
    documents = results['documents']
    metadatas = results['metadatas']

    # Tailles des chunks
    sizes = [len(doc) for doc in documents]
    size_stats = {
        'min': min(sizes),
        'max': max(sizes),
        'mean': round(statistics.mean(sizes), 0),
        'median': round(statistics.median(sizes), 0)
    }

    # Distribution par type (si disponible dans metadata)
    type_distribution = {}
    chunk_types = [meta.get('chunk_type', 'unknown') for meta in metadatas]
    type_counter = Counter(chunk_types)
    for chunk_type, count in type_counter.items():
        type_distribution[chunk_type] = count

    # Top mots-clés (seulement si detailed)
    top_keywords = []
    if detailed:
        print("[INFO] Extraction des mots-cles (peut prendre du temps)...")
        top_keywords = extract_keywords(documents, top_n=10)

    # Métadonnées disponibles
    metadata_fields = {}
    if metadatas:
        all_keys = set()
        for meta in metadatas:
            all_keys.update(meta.keys())

        for key in all_keys:
            count = sum(1 for meta in metadatas if key in meta)
            metadata_fields[key] = {
                'count': count,
                'coverage': round(count / len(metadatas) * 100, 1)
            }

    # Taille disque
    disk_size_mb = get_directory_size(chroma_path_obj)

    # Date de création (approximée via modification du dossier)
    try:
        created_timestamp = os.path.getctime(chroma_path_obj)
        created_date = datetime.fromtimestamp(created_timestamp).isoformat()
    except Exception:
        created_date = None

    try:
        modified_timestamp = os.path.getmtime(chroma_path_obj)
        modified_date = datetime.fromtimestamp(modified_timestamp).isoformat()
    except Exception:
        modified_date = None

    # Compilation des stats
    stats = {
        'collection': collection_name,
        'timestamp': datetime.now().isoformat(),
        'total_chunks': total_chunks,
        'sample_size': sample_size,
        'disk_size_mb': disk_size_mb,
        'created_date': created_date,
        'modified_date': modified_date,
        'size_stats': size_stats,
        'type_distribution': type_distribution,
        'top_keywords': top_keywords,
        'metadata_fields': metadata_fields
    }

    return stats


def format_output_table(stats: Dict) -> str:
    """
    Formate les statistiques en table texte.

    Args:
        stats: Dictionnaire de statistiques

    Returns:
        Texte formaté
    """
    lines = []

    lines.append("=" * 70)
    lines.append(f"STATISTIQUES COLLECTION: {stats['collection']}")
    lines.append("=" * 70)
    lines.append("")

    lines.append("Informations generales:")
    lines.append(f"  Total chunks:          {stats['total_chunks']}")
    lines.append(f"  Echantillon analyse:   {stats['sample_size']}")
    if stats.get('created_date'):
        lines.append(f"  Creee le:              {stats['created_date'][:19]}")
    if stats.get('modified_date'):
        lines.append(f"  Derniere MAJ:          {stats['modified_date'][:19]}")
    lines.append(f"  Espace disque:         {stats['disk_size_mb']} MB")
    lines.append("")

    lines.append("Distribution des tailles:")
    size_stats = stats['size_stats']
    lines.append(f"  Minimum:               {int(size_stats['min'])} caracteres")
    lines.append(f"  Maximum:               {int(size_stats['max'])} caracteres")
    lines.append(f"  Moyenne:               {int(size_stats['mean'])} caracteres")
    lines.append(f"  Mediane:               {int(size_stats['median'])} caracteres")
    lines.append("")

    if stats.get('type_distribution'):
        lines.append("Distribution par type:")
        for chunk_type, count in stats['type_distribution'].items():
            percentage = round(count / stats['total_chunks'] * 100, 1)
            lines.append(f"  {chunk_type}:  {count} ({percentage}%)")
        lines.append("")

    if stats.get('top_keywords'):
        lines.append("Top 10 mots-cles:")
        for i, kw in enumerate(stats['top_keywords'], 1):
            lines.append(f"  {i}. {kw['word']} ({kw['count']} occurrences)")
        lines.append("")

    if stats.get('metadata_fields'):
        lines.append("Metadonnees disponibles:")
        for field, info in stats['metadata_fields'].items():
            lines.append(f"  - {field}: {info['count']}/{stats['sample_size']} ({info['coverage']}%)")
        lines.append("")

    lines.append("=" * 70)

    return "\n".join(lines)


def format_output_markdown(stats: Dict) -> str:
    """
    Formate les statistiques en Markdown.

    Args:
        stats: Dictionnaire de statistiques

    Returns:
        Markdown formaté
    """
    lines = []

    lines.append(f"# Statistiques Collection: {stats['collection']}")
    lines.append("")

    lines.append("## Informations générales")
    lines.append("")
    lines.append(f"- **Total chunks**: {stats['total_chunks']}")
    lines.append(f"- **Échantillon analysé**: {stats['sample_size']}")
    if stats.get('created_date'):
        lines.append(f"- **Créée le**: {stats['created_date'][:19]}")
    if stats.get('modified_date'):
        lines.append(f"- **Dernière MAJ**: {stats['modified_date'][:19]}")
    lines.append(f"- **Espace disque**: {stats['disk_size_mb']} MB")
    lines.append("")

    lines.append("## Distribution des tailles")
    lines.append("")
    lines.append("| Métrique | Valeur |")
    lines.append("|----------|--------|")
    size_stats = stats['size_stats']
    lines.append(f"| Minimum | {int(size_stats['min'])} caractères |")
    lines.append(f"| Maximum | {int(size_stats['max'])} caractères |")
    lines.append(f"| Moyenne | {int(size_stats['mean'])} caractères |")
    lines.append(f"| Médiane | {int(size_stats['median'])} caractères |")
    lines.append("")

    if stats.get('type_distribution'):
        lines.append("## Distribution par type")
        lines.append("")
        for chunk_type, count in stats['type_distribution'].items():
            percentage = round(count / stats['total_chunks'] * 100, 1)
            lines.append(f"- **{chunk_type}**: {count} ({percentage}%)")
        lines.append("")

    if stats.get('top_keywords'):
        lines.append("## Top 10 mots-clés")
        lines.append("")
        for i, kw in enumerate(stats['top_keywords'], 1):
            lines.append(f"{i}. **{kw['word']}** ({kw['count']} occurrences)")
        lines.append("")

    if stats.get('metadata_fields'):
        lines.append("## Métadonnées disponibles")
        lines.append("")
        for field, info in stats['metadata_fields'].items():
            lines.append(f"- `{field}`: {info['count']}/{stats['sample_size']} ({info['coverage']}%)")
        lines.append("")

    return "\n".join(lines)


def execute(args):
    """Exécute la commande rag-stats."""

    try:
        # Calculer les statistiques
        if args.verbose:
            print(f"[INFO] Analyse de la collection '{args.collection}'...")

        stats = compute_stats(
            chroma_path=args.chroma_path,
            collection_name=args.collection,
            detailed=args.detailed
        )

        # Afficher selon le format
        if args.format == 'json':
            output = json.dumps(stats, ensure_ascii=False, indent=2)
        elif args.format == 'markdown':
            output = format_output_markdown(stats)
        else:  # table
            output = format_output_table(stats)

        print(output)

        # Export si demandé
        if args.export:
            export_path = Path(args.export)
            with open(export_path, 'w', encoding='utf-8') as f:
                json.dump(stats, f, ensure_ascii=False, indent=2)
            print()
            print(f"[OK] Statistiques exportees: {args.export}")

        return 0

    except Exception as e:
        print(f"[ERROR] {e}")
        if args.verbose:
            import traceback
            traceback.print_exc()
        return 1


def register_rag_stats_command(subparsers):
    """Enregistre la commande rag-stats."""
    parser = subparsers.add_parser(
        'rag-stats',
        help='Affiche les statistiques detaillees d\'une collection RAG'
    )

    parser.add_argument(
        '--collection',
        type=str,
        required=True,
        help='Nom de la collection ChromaDB'
    )
    parser.add_argument(
        '--format',
        type=str,
        choices=['table', 'json', 'markdown'],
        default='table',
        help='Format de sortie: table, json, markdown (defaut: table)'
    )
    parser.add_argument(
        '--export',
        type=str,
        help='Exporter les statistiques en JSON vers ce fichier'
    )
    parser.add_argument(
        '--detailed',
        action='store_true',
        help='Statistiques detaillees (analyse tous les chunks, plus lent)'
    )
    parser.add_argument(
        '--chroma-path',
        type=str,
        default='./chroma_db',
        help='Chemin vers ChromaDB (defaut: ./chroma_db)'
    )
    parser.add_argument(
        '-v', '--verbose',
        action='store_true',
        help='Affichage detaille'
    )

    parser.set_defaults(func=execute)
