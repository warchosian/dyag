"""
RAG Results Comparison

Compares two RAG evaluation results and generates comparison metrics.
"""

import json
from pathlib import Path
from typing import Dict, List
from dyag.rag.core.report_generator import calculate_similarity


def load_results(filepath: str) -> Dict:
    """Load evaluation results from JSON file."""
    with open(filepath, 'r', encoding='utf-8') as f:
        return json.load(f)


def analyze_results(results: Dict) -> Dict:
    """
    Analyze evaluation results and calculate metrics.

    Args:
        results: Evaluation results data

    Returns:
        Dictionary of calculated metrics
    """
    questions_data = results.get('results', [])
    successful = [q for q in questions_data if q.get('success', False)]

    if not successful:
        return {
            'total_questions': len(questions_data),
            'successful': 0,
            'failed': len(questions_data),
            'avg_similarity': 0.0,
            'avg_time': 0.0,
            'avg_tokens': 0.0,
            'total_time': 0.0,
            'total_tokens': 0
        }

    # Calculate similarities
    similarities = []
    for q in successful:
        answer = q.get('answer', '')
        expected = q.get('expected', '')
        sim = calculate_similarity(expected, answer)
        similarities.append(sim)

    # Calculate metrics
    avg_similarity = sum(similarities) / len(similarities) if similarities else 0.0
    avg_time = sum(q.get('time') or 0 for q in successful) / len(successful)
    avg_tokens = sum(q.get('tokens') or 0 for q in successful) / len(successful)
    total_time = sum(q.get('time') or 0 for q in successful)
    total_tokens = sum(q.get('tokens') or 0 for q in successful)

    return {
        'total_questions': len(questions_data),
        'successful': len(successful),
        'failed': len(questions_data) - len(successful),
        'avg_similarity': avg_similarity,
        'avg_time': avg_time,
        'avg_tokens': avg_tokens,
        'total_time': total_time,
        'total_tokens': total_tokens,
        'similarities': similarities
    }


def calculate_improvements(baseline_metrics: Dict, improved_metrics: Dict) -> Dict:
    """
    Calculate improvement metrics between baseline and improved results.

    Args:
        baseline_metrics: Baseline metrics dictionary
        improved_metrics: Improved metrics dictionary

    Returns:
        Dictionary with improvement deltas and percentages
    """
    improvements = {}

    # Calculate similarity improvement
    baseline_sim = baseline_metrics.get('avg_similarity', 0.0)
    improved_sim = improved_metrics.get('avg_similarity', 0.0)
    improvements['similarity_delta'] = improved_sim - baseline_sim

    if baseline_sim > 0:
        improvements['similarity_improvement'] = ((improved_sim - baseline_sim) / baseline_sim) * 100
    else:
        improvements['similarity_improvement'] = 0.0 if improved_sim == 0 else float('inf')

    # Calculate success rate improvement
    baseline_success = baseline_metrics.get('successful', 0)
    improved_success = improved_metrics.get('successful', 0)
    improvements['success_delta'] = improved_success - baseline_success

    baseline_total = baseline_metrics.get('total_questions', 1)
    improved_total = improved_metrics.get('total_questions', 1)

    baseline_rate = baseline_success / baseline_total if baseline_total > 0 else 0
    improved_rate = improved_success / improved_total if improved_total > 0 else 0

    if baseline_rate > 0:
        improvements['success_improvement'] = ((improved_rate - baseline_rate) / baseline_rate) * 100
    else:
        improvements['success_improvement'] = 0.0 if improved_rate == 0 else float('inf')

    # Calculate time improvement (lower is better)
    baseline_time = baseline_metrics.get('avg_time', 0.0)
    improved_time = improved_metrics.get('avg_time', 0.0)
    improvements['time_delta'] = improved_time - baseline_time

    if baseline_time > 0:
        improvements['time_improvement'] = ((baseline_time - improved_time) / baseline_time) * 100
    else:
        improvements['time_improvement'] = 0.0

    return improvements


def print_comparison_report(baseline: Dict, improved: Dict) -> None:
    """
    Print comparison report between two result sets.

    Args:
        baseline: Baseline results (before improvements)
        improved: Improved results (after improvements)
    """
    print("=" * 80)
    print("COMPARAISON DES RÉSULTATS RAG")
    print("=" * 80)
    print()

    # Configuration info
    baseline_meta = baseline.get('metadata', {})
    improved_meta = improved.get('metadata', {})

    print("CONFIGURATION")
    print("-" * 80)
    print(f"Baseline:")
    print(f"  Modèle LLM: {baseline_meta.get('model', 'N/A')}")
    print(f"  Embedding: {baseline_meta.get('embedding_model', 'N/A')}")
    print(f"  Collection: {baseline_meta.get('collection', 'N/A')}")
    print(f"  Date: {baseline_meta.get('timestamp', 'N/A')[:19]}")
    print()
    print(f"Amélioré:")
    print(f"  Modèle LLM: {improved_meta.get('model', 'N/A')}")
    print(f"  Embedding: {improved_meta.get('embedding_model', 'N/A')}")
    print(f"  Collection: {improved_meta.get('collection', 'N/A')}")
    print(f"  Date: {improved_meta.get('timestamp', 'N/A')[:19]}")
    print()

    # Analyze results
    baseline_stats = analyze_results(baseline)
    improved_stats = analyze_results(improved)

    # Metrics comparison
    print("MÉTRIQUES")
    print("-" * 80)

    metrics = [
        ("Questions totales", 'total_questions', '', False),
        ("Succès", 'successful', '', False),
        ("Échecs", 'failed', '', True),
        ("Similarité moyenne", 'avg_similarity', '%', False),
        ("Temps moyen", 'avg_time', 's', True),
        ("Tokens moyens", 'avg_tokens', '', True),
        ("Temps total", 'total_time', 's', True),
        ("Tokens total", 'total_tokens', '', True),
    ]

    for label, key, unit, lower_is_better in metrics:
        baseline_val = baseline_stats[key]
        improved_val = improved_stats[key]

        if isinstance(baseline_val, float):
            if unit == '%':
                baseline_str = f"{baseline_val * 100:6.1f}%"
                improved_str = f"{improved_val * 100:6.1f}%"
            else:
                baseline_str = f"{baseline_val:8.1f}{unit}"
                improved_str = f"{improved_val:8.1f}{unit}"
        else:
            baseline_str = f"{baseline_val:8}{unit}"
            improved_str = f"{improved_val:8}{unit}"

        # Calculate delta
        if baseline_val != 0:
            if lower_is_better:
                delta = ((baseline_val - improved_val) / baseline_val) * 100
            else:
                delta = ((improved_val - baseline_val) / baseline_val) * 100
            sign = '+' if delta > 0 else ''
        else:
            delta = 0
            sign = ''

        delta_str = f"{sign}{delta:5.1f}%" if delta != 0 else "   —"

        print(f"{label:20} {baseline_str:>12} → {improved_str:>12}  ({delta_str})")

    print()

    # Similarity distribution
    if improved_stats['similarities']:
        print("DISTRIBUTION DES SIMILARITÉS")
        print("-" * 80)

        sims = improved_stats['similarities']
        excellent = sum(1 for s in sims if s >= 0.8)
        good = sum(1 for s in sims if 0.6 <= s < 0.8)
        medium = sum(1 for s in sims if 0.4 <= s < 0.6)
        poor = sum(1 for s in sims if s < 0.4)
        total = len(sims)

        print(f"Excellentes (≥80%): {excellent:3} ({excellent/total*100:5.1f}%)")
        print(f"Bonnes (60-80%):   {good:3} ({good/total*100:5.1f}%)")
        print(f"Moyennes (40-60%): {medium:3} ({medium/total*100:5.1f}%)")
        print(f"Faibles (<40%):    {poor:3} ({poor/total*100:5.1f}%)")
        print()

    # Conclusion
    print("CONCLUSION")
    print("-" * 80)

    sim_improvement = (improved_stats['avg_similarity'] - baseline_stats['avg_similarity']) * 100

    if sim_improvement > 20:
        print(f"✅ Amélioration significative de +{sim_improvement:.1f} points de similarité")
    elif sim_improvement > 10:
        print(f"✓ Amélioration notable de +{sim_improvement:.1f} points de similarité")
    elif sim_improvement > 0:
        print(f"⚠ Amélioration légère de +{sim_improvement:.1f} points de similarité")
    else:
        print(f"❌ Régression de {sim_improvement:.1f} points de similarité")

    # Recommendations
    if improved_stats['avg_similarity'] < 0.6:
        print("\nRECOMMANDATIONS:")
        print("- Similarité encore faible (<60%)")
        print("- Envisager Phase 2 : reranking + hybrid search")
        print("- Vérifier la qualité des chunks et des métadonnées")
    elif improved_stats['avg_similarity'] < 0.75:
        print("\nRECOMMANDATIONS:")
        print("- Similarité acceptable (60-75%)")
        print("- Possible optimisation avec Phase 2")
    else:
        print("\nOBJECTIF ATTEINT:")
        print("- Similarité excellente (≥75%)")
        print("- Système prêt pour production")

    print()
    print("=" * 80)


def compare_results(baseline_path: str, improved_path: str) -> int:
    """
    Compare two RAG evaluation result files.

    Args:
        baseline_path: Path to baseline results JSON
        improved_path: Path to improved results JSON

    Returns:
        Exit code (0 for success)
    """
    # Verify files exist
    if not Path(baseline_path).exists():
        print(f"[ERROR] Fichier baseline introuvable: {baseline_path}")
        return 1

    if not Path(improved_path).exists():
        print(f"[ERROR] Fichier improved introuvable: {improved_path}")
        return 1

    # Load results
    try:
        baseline = load_results(baseline_path)
        improved = load_results(improved_path)
    except Exception as e:
        print(f"[ERROR] Erreur de chargement: {e}")
        return 1

    # Print comparison
    print_comparison_report(baseline, improved)

    return 0
