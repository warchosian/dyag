"""
Système de Q&A avec RAG pour interroger les chunks d'applications.

Ce module permet de poser des questions en langage naturel et obtenir
des réponses précises basées sur les chunks indexés.
"""

import os
# Configurer HF_HOME avant d'importer sentence_transformers
# (remplace l'ancien TRANSFORMERS_CACHE qui est déprécié)
if 'TRANSFORMERS_CACHE' in os.environ and 'HF_HOME' not in os.environ:
    os.environ['HF_HOME'] = os.environ['TRANSFORMERS_CACHE']

# Désactiver la telemetry ChromaDB pour éviter les erreurs
os.environ['ANONYMIZED_TELEMETRY'] = 'False'

import chromadb
import logging

# Supprimer les messages d'erreur de telemetry ChromaDB
logging.getLogger('chromadb.telemetry.product.posthog').setLevel(logging.CRITICAL)
from sentence_transformers import SentenceTransformer, CrossEncoder
import sys
import io
from typing import List, Dict, Optional
from pathlib import Path
import json
from dotenv import load_dotenv

# Fixer l'encodage UTF-8 pour Windows (seulement si exécuté comme script principal)
if sys.platform == 'win32' and __name__ == '__main__':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')

# Support pour import direct ou module
try:
    from .llm_providers import LLMProviderFactory
except ImportError:
    # Ajouter le répertoire parent au path pour import direct
    sys.path.insert(0, str(Path(__file__).parent))
    from llm_providers import LLMProviderFactory

# Charger les variables d'environnement depuis .env
env_path = Path(__file__).parent.parent.parent / '.env'
if env_path.exists():
    load_dotenv(env_path)
else:
    load_dotenv()


class RAGQuerySystem:
    """
    Système de Q&A avec Retrieval Augmented Generation.

    Permet de poser des questions en langage naturel et obtenir des
    réponses précises basées sur les chunks d'applications.
    """

    def __init__(
        self,
        chroma_path: str = "./chroma_db",
        collection_name: str = "applications",
        embedding_model: Optional[str] = None,
        llm_provider: Optional[str] = None,
        llm_model: Optional[str] = None,
        api_key: Optional[str] = None,
        timeout: Optional[int] = None,
        rerank_model: Optional[str] = "cross-encoder/ms-marco-MiniLM-L-6-v2"
    ):
        """
        Initialise le système RAG.

        Args:
            chroma_path: Chemin vers la base ChromaDB
            collection_name: Nom de la collection ChromaDB
            embedding_model: Modèle Sentence Transformers pour embeddings
            llm_provider: Provider LLM ('openai', 'anthropic', 'claude', 'ollama')
                         Si None, détecté automatiquement depuis .env
            llm_model: Modèle LLM spécifique
                      Si None, utilise le modèle par défaut du provider
            api_key: Clé API du provider
                    Si None, récupérée depuis les variables d'environnement
            timeout: Timeout en secondes (uniquement pour Ollama)
                    Si None, utilise OLLAMA_TIMEOUT depuis .env (défaut: 300s)
            rerank_model: Modèle CrossEncoder pour reranking (chargé à la demande)
                         Si None, le reranking est désactivé
        """
        # ChromaDB
        self.chroma_path = Path(chroma_path)
        self.client = chromadb.PersistentClient(path=str(self.chroma_path))

        try:
            self.collection = self.client.get_collection(collection_name)
        except Exception:
            raise ValueError(
                f"Collection '{collection_name}' non trouvée. "
                f"Veuillez d'abord indexer vos chunks avec index_chunks.py"
            )

        # Modèle d'embedding (depuis .env si non spécifié)
        if embedding_model is None:
            embedding_model = os.getenv('EMBEDDING_MODEL', 'all-MiniLM-L6-v2')
        print(f"Chargement du modèle d'embedding: {embedding_model}")
        self.embedding_model = SentenceTransformer(embedding_model)

        # Reranker (chargé à la demande)
        self.rerank_model_name = rerank_model
        self._reranker = None

        # LLM Provider
        print(f"Initialisation du provider LLM...")
        try:
            self.llm_provider = LLMProviderFactory.create_provider(
                provider=llm_provider,
                model=llm_model,
                api_key=api_key,
                timeout=timeout
            )
            print(f"[OK] Provider LLM: {self.llm_provider.get_model_name()}")
        except Exception as e:
            raise ValueError(f"Erreur d'initialisation du provider LLM: {e}")

    @property
    def reranker(self):
        """Charge le reranker à la demande (lazy loading)."""
        if self._reranker is None and self.rerank_model_name:
            print(f"Chargement du modèle de reranking: {self.rerank_model_name}")
            self._reranker = CrossEncoder(self.rerank_model_name)
        return self._reranker

    def search_chunks(
        self,
        query: str,
        n_results: int = 5,
        filter_metadata: Optional[Dict] = None
    ) -> List[Dict]:
        """
        Recherche les chunks les plus pertinents pour une question.

        Args:
            query: Question en langage naturel
            n_results: Nombre de chunks à récupérer (top K)
            filter_metadata: Filtres optionnels sur les métadonnées
                           Ex: {"source_id": "383"} pour une app spécifique

        Returns:
            Liste de chunks avec leurs scores de similarité
        """
        # Générer embedding de la question
        query_embedding = self.embedding_model.encode(query).tolist()

        # Rechercher dans ChromaDB
        results = self.collection.query(
            query_embeddings=[query_embedding],
            n_results=n_results,
            where=filter_metadata
        )

        # Formater résultats
        chunks = []
        for i in range(len(results['ids'][0])):
            chunks.append({
                'id': results['ids'][0][i],
                'content': results['documents'][0][i],
                'metadata': results['metadatas'][0][i],
                'distance': results['distances'][0][i]
            })

        return chunks

    def rerank_chunks(
        self,
        query: str,
        chunks: List[Dict],
        top_k: Optional[int] = None
    ) -> List[Dict]:
        """
        Reordonne les chunks par pertinence avec CrossEncoder.

        Args:
            query: Question de l'utilisateur
            chunks: Chunks initiaux récupérés par recherche vectorielle
            top_k: Nombre de chunks à retenir après reranking
                  Si None, retourne tous les chunks réordonnés

        Returns:
            Chunks réordonnés par score de pertinence
        """
        if not self.reranker or not chunks:
            return chunks

        # Créer paires (query, chunk_content)
        pairs = [[query, chunk['content']] for chunk in chunks]

        # Calculer scores de pertinence
        scores = self.reranker.predict(pairs)

        # Ajouter scores aux chunks et trier
        for i, chunk in enumerate(chunks):
            chunk['rerank_score'] = float(scores[i])

        # Trier par score décroissant
        reranked = sorted(chunks, key=lambda x: x['rerank_score'], reverse=True)

        # Retourner top_k si spécifié
        if top_k:
            return reranked[:top_k]

        return reranked

    def generate_answer(
        self,
        question: str,
        chunks: List[Dict],
        system_prompt: Optional[str] = None,
        temperature: float = 0.3,
        max_tokens: int = 1000
    ) -> Dict:
        """
        Génère une réponse avec le LLM basée sur les chunks de contexte.

        Args:
            question: Question de l'utilisateur
            chunks: Chunks de contexte récupérés
            system_prompt: Prompt système personnalisé (optionnel)
            temperature: Créativité du modèle (0=précis, 1=créatif)
            max_tokens: Longueur maximale de la réponse

        Returns:
            Dictionnaire avec réponse, sources, et métadonnées
        """
        # Construire le contexte à partir des chunks
        # Inclure les métadonnées critiques (app_id, app_name) pour aider le LLM
        context = "\n\n---\n\n".join([
            f"[Extrait {i+1}]\n"
            f"APP_ID: {c['metadata'].get('app_id', 'N/A')}\n"
            f"APP_NAME: {c['metadata'].get('app_name', 'N/A')}\n\n"
            f"{c['content']}"
            for i, c in enumerate(chunks)
        ])

        # Prompt système par défaut optimisé pour réponses concises
        if system_prompt is None:
            system_prompt = """Tu es un assistant expert qui répond de manière précise et concise aux questions sur des applications métier.

INSTRUCTIONS:

1. Réponds DIRECTEMENT à la question posée en 1-2 phrases maximum
2. Base-toi UNIQUEMENT sur les informations du contexte fourni
3. Si l'information n'est pas disponible, dis simplement "Non disponible"
4. N'invente JAMAIS d'informations
5. Ne reproduis PAS le format question/réponse dans ta réponse

RÈGLES SPÉCIFIQUES:

- IDENTIFIANTS: Utilise le champ APP_ID (ex: "1238"), jamais les UUIDs hexadécimaux
- CONTACTS: Liste tous les noms et emails trouvés (format: "Nom <email>")
- DOMAINES: Donne le chemin complet si disponible (ex: "Environnement > Biodiversité")
- Ne mentionne jamais les extraits ou sources dans ta réponse

EXEMPLES DE BONNES RÉPONSES:

Question: "Qu'est-ce que LEJIS ?"
Réponse: "LEJIS est une application de suivi des lois et politiques publiques dans le domaine juridique."

Question: "Quel est l'identifiant de 6Tzen ?"
Réponse: "1238"

Question: "Qui contacter pour ADES ?"
Réponse: "Jean Dupont <jean.dupont@example.fr>"
"""

        # Prompt utilisateur
        user_prompt = f"""Contexte:
{context}

Question: {question}

Instructions:
- Réponds de manière précise et détaillée
- Base-toi UNIQUEMENT sur le contexte fourni
- Cite tes sources (IDs des chunks) entre crochets
- Si tu ne sais pas ou si l'information n'est pas dans le contexte, dis-le clairement
- Structure ta réponse de façon claire"""

        # Appel au LLM via le provider
        response = self.llm_provider.chat_completion(
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            temperature=temperature,
            max_tokens=max_tokens
        )

        return {
            'answer': response['content'],
            'sources': [c['id'] for c in chunks],
            'chunks_used': chunks,
            'model': self.llm_provider.get_model_name(),
            'tokens_used': response['usage']['total_tokens'],
            'prompt_tokens': response['usage']['prompt_tokens'],
            'completion_tokens': response['usage']['completion_tokens']
        }

    def ask(
        self,
        question: str,
        n_chunks: int = 5,
        filter_metadata: Optional[Dict] = None,
        temperature: float = 0.3,
        use_reranking: bool = True,  # Phase 2.5: Activé par défaut
        rerank_top_k: Optional[int] = None
    ) -> Dict:
        """
        Méthode tout-en-un pour poser une question.

        Args:
            question: Question en langage naturel
            n_chunks: Nombre de chunks à récupérer initialement
            filter_metadata: Filtres optionnels sur les métadonnées
            temperature: Créativité du modèle (0=précis, 1=créatif)
            use_reranking: Si True, réordonne les chunks avec CrossEncoder
            rerank_top_k: Nombre de chunks après reranking (défaut: n_chunks)

        Returns:
            Réponse complète avec sources et métadonnées

        Example:
            >>> rag = RAGQuerySystem()
            >>> # Sans reranking
            >>> result = rag.ask("Qui héberge GIDAF ?")
            >>> # Avec reranking
            >>> result = rag.ask("Qui héberge GIDAF ?", use_reranking=True)
            >>> print(result['answer'])
        """
        # 1. Rechercher chunks pertinents
        # Si reranking activé, on récupère plus de chunks puis on rerank
        initial_k = n_chunks * 2 if use_reranking else n_chunks
        chunks = self.search_chunks(question, initial_k, filter_metadata)

        if not chunks:
            return {
                'question': question,
                'answer': "Aucun chunk pertinent trouvé pour cette question.",
                'sources': [],
                'chunks_used': [],
                'tokens_used': 0,
                'reranked': False
            }

        # 2. Reranking optionnel
        if use_reranking and self.rerank_model_name:
            top_k = rerank_top_k if rerank_top_k else n_chunks
            chunks = self.rerank_chunks(question, chunks, top_k=top_k)
            reranked = True
        else:
            reranked = False

        # 3. Générer réponse
        result = self.generate_answer(question, chunks, temperature=temperature)

        # 4. Ajouter métadonnées
        result['question'] = question
        result['reranked'] = reranked

        return result

    def get_stats(self) -> Dict:
        """
        Récupère les statistiques de la base vectorielle.

        Returns:
            Statistiques (nombre de chunks, etc.)
        """
        count = self.collection.count()

        return {
            'total_chunks': count,
            'collection_name': self.collection.name,
            'embedding_model': self.embedding_model,
            'llm_model': self.llm_provider.get_model_name()
        }


def main():
    """
    Fonction principale pour tester le système en ligne de commande.
    """
    import sys
    import argparse

    parser = argparse.ArgumentParser(
        description="Système de Q&A avec RAG pour interroger les applications"
    )
    parser.add_argument(
        '--query',
        type=str,
        help='Question à poser (mode non-interactif)'
    )
    parser.add_argument(
        '--n-chunks',
        type=int,
        default=5,
        help='Nombre de chunks de contexte (défaut: 5)'
    )
    parser.add_argument(
        '--timeout',
        type=int,
        help='Timeout en secondes pour Ollama (défaut: 300s ou OLLAMA_TIMEOUT dans .env)'
    )

    args = parser.parse_args()

    print("Initialisation du système RAG...")
    rag = RAGQuerySystem(timeout=args.timeout)

    print(f"\nStatistiques:")
    stats = rag.get_stats()
    print(f"  - Chunks indexés: {stats['total_chunks']}")
    print(f"  - Modèle LLM: {stats['llm_model']}")

    # Mode question directe
    if args.query:
        print(f"\n❓ Question: {args.query}")
        print("\n🔍 Recherche en cours...")

        result = rag.ask(args.query, n_chunks=args.n_chunks)

        print(f"\n💬 Réponse:")
        print(result['answer'])

        print(f"\n📊 Métadonnées:")
        print(f"  - Sources: {len(result['sources'])} chunks")
        print(f"  - Tokens: {result['tokens_used']}")
        print(f"  - IDs: {', '.join(result['sources'][:3])}...")

        return

    # Mode interactif
    print("\n" + "=" * 60)
    print("Mode interactif - Posez vos questions (Ctrl+C pour quitter)")
    print("=" * 60)

    while True:
        try:
            question = input("\n❓ Question: ")

            if not question.strip():
                continue

            print("\n🔍 Recherche en cours...")
            result = rag.ask(question)

            print(f"\n💬 Réponse:")
            print(result['answer'])

            print(f"\n📊 Métadonnées:")
            print(f"  - Sources: {len(result['sources'])} chunks")
            print(f"  - Tokens: {result['tokens_used']}")
            print(f"  - IDs: {', '.join(result['sources'][:3])}...")

        except KeyboardInterrupt:
            print("\n\nAu revoir!")
            break
        except Exception as e:
            print(f"\n❌ Erreur: {e}")


if __name__ == '__main__':
    main()
