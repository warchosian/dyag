"""
Module Processing - DYAG

Traitement et manipulation de documents (PDF, HTML, Markdown).
"""

# Les commandes sont dans le sous-module commands
# Usage: from dyag.processing.commands.compress_pdf import compress_pdf
