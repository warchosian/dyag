#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Test du serveur MCP DYAG - Multiplateforme

Module : dyag.mcp.commands.test_mcp
Commande CLI : python -m dyag.mcp.commands.test_mcp
Ou via CLI : python -m dyag test-mcp (si configuré dans __main__.py)
"""

import sys
import subprocess
import time
import signal
from pathlib import Path
import platform


def print_header(text):
    """Afficher un en-tête formaté"""
    print("\n" + "=" * 70)
    print(text)
    print("=" * 70)


def print_test(number, total, description):
    """Afficher le début d'un test"""
    print(f"\n[TEST {number}/{total}] {description}...")


def print_result(success, message=""):
    """Afficher le résultat d'un test"""
    status = "[OK]" if success else "[FAIL]"
    print(f"{status} {message}")
    return success


def test_module_exists():
    """Test 1: Vérifier que le fichier server.py existe"""
    print_test(1, 5, "Fichier mcp/server.py")

    mcp_file = Path(__file__).parent / "server.py"
    exists = mcp_file.exists()

    if exists:
        return print_result(True, f"Trouvé : {mcp_file}")
    else:
        return print_result(False, f"Introuvable : {mcp_file}")


def test_import_dyag():
    """Test 2: Vérifier que dyag peut être importé"""
    print_test(2, 5, "Import package dyag")

    try:
        import dyag
        return print_result(True, "Package dyag importé")
    except ImportError as e:
        return print_result(False, f"Erreur import : {e}")


def test_import_commands():
    """Test 3: Vérifier les imports des commandes"""
    print_test(3, 5, "Import commandes RAG")

    success = True

    # Test img2pdf
    try:
        from dyag.commands.img2pdf import images_to_pdf
        print_result(True, "dyag.commands.img2pdf")
    except ImportError as e:
        print_result(False, f"dyag.commands.img2pdf : {e}")
        success = False

    # Test index_rag
    try:
        from dyag.rag.commands.index_rag import ChunkIndexer
        print_result(True, "dyag.rag.commands.index_rag")
    except ImportError as e:
        print_result(False, f"dyag.rag.commands.index_rag : {e}")
        success = False

    # Test evaluate_rag
    try:
        from dyag.rag.commands.evaluate_rag import load_dataset
        print_result(True, "dyag.rag.commands.evaluate_rag")
    except ImportError as e:
        print_result(False, f"dyag.rag.commands.evaluate_rag : {e}")
        success = False

    return success


def test_server_startup():
    """Test 4: Vérifier que le serveur démarre sans erreur"""
    print_test(4, 5, "Démarrage serveur MCP")

    try:
        # Lancer le serveur MCP
        process = subprocess.Popen(
            [sys.executable, "-m", "dyag.mcp.server"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )

        # Attendre 2 secondes
        time.sleep(2)

        # Vérifier s'il y a des erreurs
        if process.poll() is not None:
            # Le processus s'est terminé (erreur)
            stdout, stderr = process.communicate()
            return print_result(False, f"Serveur crashé : {stderr[:200]}")

        # Tuer le processus proprement
        if platform.system() == "Windows":
            process.send_signal(signal.CTRL_C_EVENT)
        else:
            process.send_signal(signal.SIGTERM)

        try:
            process.wait(timeout=2)
        except subprocess.TimeoutExpired:
            process.kill()

        return print_result(True, "Serveur démarre correctement")

    except Exception as e:
        return print_result(False, f"Erreur : {e}")


def test_list_tools():
    """Test 5: Lister les outils MCP disponibles"""
    print_test(5, 5, "Outils MCP disponibles")

    expected_tools = [
        "dyag_img2pdf",
        "dyag_compresspdf",
        "dyag_md2html",
        "dyag_analyze_training",
        "dyag_index_rag",
        "dyag_rag_query",
        "dyag_evaluate_rag",
        "dyag_generate_questions",
        "dyag_generate_evaluation_report",
    ]

    print(f"\n   Les {len(expected_tools)} outils MCP attendus :")
    for i, tool in enumerate(expected_tools, 1):
        print(f"     {i:2}. {tool}")

    return print_result(True, f"{len(expected_tools)} outils disponibles")


def print_next_steps():
    """Afficher les prochaines étapes"""
    print("\n" + "=" * 70)
    print("PROCHAINES ÉTAPES")
    print("=" * 70)

    print("\n1. Configurer Claude Desktop")

    if platform.system() == "Windows":
        config_path = "%APPDATA%\\Claude\\claude_desktop_config.json"
    else:
        config_path = "~/Library/Application Support/Claude/claude_desktop_config.json"

    print(f"   Fichier : {config_path}")

    print("\n2. Ajouter la configuration MCP :")
    print("""
   {
     "mcpServers": {
       "dyag": {
         "command": "python",
         "args": ["-m", "dyag.mcp_server"],
         "cwd": "<chemin_absolu_vers_dyag>"
       }
     }
   }
   """)

    print("3. Redémarrer Claude Desktop complètement")

    print("\n4. Dans Claude Desktop, demander :")
    print('   "Quels outils MCP DYAG as-tu ?"')

    print("\n5. Tester avec une vraie requête :")
    print('   "Utilise dyag_rag_query pour répondre :')
    print('    Question : Qui contacter pour 6Tzen ?')
    print('    Base : ./chroma_db_10apps_phase251')
    print('    Collection : applications_phase251"')


def main():
    """Point d'entrée principal"""
    print_header("TEST SERVEUR MCP DYAG - MULTIPLATEFORME")

    print(f"\nPlateforme : {platform.system()} {platform.release()}")
    print(f"Python     : {sys.version.split()[0]}")
    print(f"Exécutable : {sys.executable}")

    # Exécuter les tests
    results = []

    results.append(test_module_exists())
    results.append(test_import_dyag())
    results.append(test_import_commands())
    results.append(test_server_startup())
    results.append(test_list_tools())

    # Résumé
    total = len(results)
    success_count = sum(results)
    failed_count = total - success_count

    print_header("RÉSUMÉ")
    print(f"\nTests réussis : {success_count}/{total}")
    print(f"Tests échoués : {failed_count}/{total}")

    if failed_count == 0:
        print("\n✓ TOUS LES TESTS PASSENT")
        print("✓ Le serveur MCP DYAG est opérationnel !")
        print_next_steps()
        return 0
    else:
        print("\n✗ CERTAINS TESTS ONT ÉCHOUÉ")
        print("\nActions recommandées :")
        print("  1. Installer le package : pip install -e .")
        print("  2. Vérifier les imports dans src/dyag/mcp_server.py")
        print("  3. Consulter le guide Phase 2.5.1 pour plus de détails")
        return 1


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\n\nTest interrompu par l'utilisateur")
        sys.exit(130)
