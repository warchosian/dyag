"""
Module MCP (Model Context Protocol) pour DYAG

Ce module contient tous les outils et serveurs MCP permettant
l'intégration de DYAG avec Claude Desktop et autres clients MCP.
"""

from .commands.mcp_server import MCPServer

__all__ = ["MCPServer"]
