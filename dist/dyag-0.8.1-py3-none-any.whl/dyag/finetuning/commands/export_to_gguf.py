"""
Commande pour exporter un modèle fine-tuné LoRA vers GGUF (Ollama).

Processus:
1. Merge adapter LoRA avec base model
2. Conversion HuggingFace → GGUF (llama.cpp)
3. Quantification (optionnelle)
4. Création modèle Ollama (optionnelle)
"""

import os
import sys
import subprocess
from pathlib import Path
from typing import Optional

def merge_lora_adapter(
    model_path: str,
    base_model: str,
    output_path: str
) -> bool:
    """
    Merge l'adapter LoRA avec le modèle de base.

    Args:
        model_path: Chemin vers l'adapter LoRA
        base_model: Nom du modèle de base
        output_path: Chemin de sortie pour le modèle mergé

    Returns:
        True si succès
    """
    try:
        from peft import PeftModel, AutoModelForCausalLM
        from transformers import AutoTokenizer
        import torch

        print(f"\n[1/4] Merge de l'adapter LoRA...")
        print(f"  Base model: {base_model}")
        print(f"  Adapter:    {model_path}")
        print(f"  Output:     {output_path}")

        # Résoudre le nom du modèle de base
        from dyag.finetuning.core.model_registry import resolve_base_model
        resolved_model = resolve_base_model(base_model)
        print(f"  Resolved:   {resolved_model}")

        # Charger le modèle de base
        print("\n  Chargement du modele de base...")
        base = AutoModelForCausalLM.from_pretrained(
            resolved_model,
            torch_dtype=torch.float16,
            device_map="cpu"
        )

        # Charger l'adapter
        print("  Chargement de l'adapter LoRA...")
        model = PeftModel.from_pretrained(base, model_path)

        # Merger
        print("  Merge en cours...")
        merged = model.merge_and_unload()

        # Sauvegarder
        print("  Sauvegarde du modele merge...")
        os.makedirs(output_path, exist_ok=True)
        merged.save_pretrained(output_path)

        # Sauvegarder le tokenizer
        print("  Sauvegarde du tokenizer...")
        tokenizer = AutoTokenizer.from_pretrained(resolved_model)
        tokenizer.save_pretrained(output_path)

        print(f"\n[OK] Modele merge sauvegarde: {output_path}")
        return True

    except ImportError as e:
        print(f"\n[ERROR] Dependances manquantes: {e}")
        print("  Installez: pip install peft transformers torch")
        return False
    except Exception as e:
        print(f"\n[ERROR] Echec du merge: {e}")
        return False


def convert_to_gguf(
    model_path: str,
    output_file: str,
    llama_cpp_path: Optional[str] = None
) -> bool:
    """
    Convertit un modèle HuggingFace en GGUF.

    Args:
        model_path: Chemin vers le modèle HuggingFace mergé
        output_file: Fichier GGUF de sortie
        llama_cpp_path: Chemin vers llama.cpp (optionnel)

    Returns:
        True si succès
    """
    print(f"\n[2/4] Conversion HuggingFace -> GGUF...")

    # Trouver llama.cpp
    if not llama_cpp_path:
        # Chercher dans répertoire parent
        possible_paths = [
            Path("../llama.cpp"),
            Path("../../llama.cpp"),
            Path.home() / "llama.cpp",
            Path("G:/Tools/llama.cpp"),
            Path("C:/Tools/llama.cpp")
        ]

        for p in possible_paths:
            if (p / "convert_hf_to_gguf.py").exists():
                llama_cpp_path = str(p)
                break

    if not llama_cpp_path or not Path(llama_cpp_path).exists():
        print("\n[ERROR] llama.cpp introuvable !")
        print("\nVeuillez:")
        print("  1. Cloner llama.cpp:")
        print("     git clone https://github.com/ggerganov/llama.cpp")
        print("  2. Puis relancer avec --llama-cpp-path")
        return False

    convert_script = Path(llama_cpp_path) / "convert_hf_to_gguf.py"
    if not convert_script.exists():
        print(f"\n[ERROR] Script introuvable: {convert_script}")
        return False

    print(f"  llama.cpp: {llama_cpp_path}")
    print(f"  Input:     {model_path}")
    print(f"  Output:    {output_file}")

    # Créer répertoire de sortie
    os.makedirs(Path(output_file).parent, exist_ok=True)

    # Lancer conversion
    cmd = [
        sys.executable,
        str(convert_script),
        model_path,
        "--outfile", output_file,
        "--outtype", "f16"
    ]

    print(f"\n  Commande: {' '.join(cmd)}")
    print("  (Cela peut prendre 2-5 minutes...)\n")

    try:
        result = subprocess.run(
            cmd,
            cwd=llama_cpp_path,
            check=True,
            capture_output=False
        )

        print(f"\n[OK] GGUF cree: {output_file}")

        # Afficher taille
        size_mb = Path(output_file).stat().st_size / (1024 * 1024)
        print(f"  Taille: {size_mb:.1f} MB")

        return True

    except subprocess.CalledProcessError as e:
        print(f"\n[ERROR] Echec de la conversion: {e}")
        return False


def quantize_gguf(
    input_file: str,
    output_file: str,
    quant_type: str,
    llama_cpp_path: str
) -> bool:
    """
    Quantifie un fichier GGUF.

    Args:
        input_file: Fichier GGUF source (FP16)
        output_file: Fichier GGUF quantifié
        quant_type: Type de quantification (Q4_K_M, Q5_K_M, etc.)
        llama_cpp_path: Chemin vers llama.cpp

    Returns:
        True si succès
    """
    print(f"\n[3/4] Quantification {quant_type}...")

    # Trouver l'exécutable llama-quantize
    quantize_exe = None
    possible_names = ["llama-quantize", "llama-quantize.exe", "quantize", "quantize.exe"]

    for name in possible_names:
        exe_path = Path(llama_cpp_path) / name
        if exe_path.exists():
            quantize_exe = str(exe_path)
            break

        # Chercher dans build/
        build_path = Path(llama_cpp_path) / "build" / "bin" / name
        if build_path.exists():
            quantize_exe = str(build_path)
            break

    if not quantize_exe:
        print(f"\n[WARNING] llama-quantize introuvable dans {llama_cpp_path}")
        print("  Vous devez compiler llama.cpp:")
        print("    cd llama.cpp && make")
        print("\n  Fichier GGUF FP16 disponible: {input_file}")
        return False

    print(f"  Input:  {input_file}")
    print(f"  Output: {output_file}")
    print(f"  Type:   {quant_type}")

    cmd = [quantize_exe, input_file, output_file, quant_type]

    print(f"\n  Commande: {' '.join(cmd)}")
    print("  (Cela peut prendre 1-2 minutes...)\n")

    try:
        subprocess.run(cmd, check=True, capture_output=False)

        print(f"\n[OK] GGUF quantifie: {output_file}")

        # Afficher comparaison tailles
        size_before = Path(input_file).stat().st_size / (1024 * 1024)
        size_after = Path(output_file).stat().st_size / (1024 * 1024)
        reduction = (1 - size_after / size_before) * 100

        print(f"  Taille avant: {size_before:.1f} MB")
        print(f"  Taille apres: {size_after:.1f} MB")
        print(f"  Reduction:    {reduction:.1f}%")

        return True

    except subprocess.CalledProcessError as e:
        print(f"\n[ERROR] Echec de la quantification: {e}")
        return False


def create_ollama_model(
    gguf_file: str,
    model_name: str,
    system_prompt: Optional[str] = None
) -> bool:
    """
    Crée un modèle Ollama à partir d'un fichier GGUF.

    Args:
        gguf_file: Chemin vers le fichier GGUF
        model_name: Nom du modèle Ollama (ex: dyag-mygusi:latest)
        system_prompt: Prompt système personnalisé

    Returns:
        True si succès
    """
    print(f"\n[4/4] Creation du modele Ollama...")

    # Vérifier qu'Ollama est installé
    try:
        subprocess.run(
            ["ollama", "list"],
            check=True,
            capture_output=True
        )
    except (subprocess.CalledProcessError, FileNotFoundError):
        print("\n[ERROR] Ollama n'est pas installe ou pas dans le PATH")
        print("  Installez depuis: https://ollama.com/download")
        return False

    # Créer Modelfile
    if not system_prompt:
        system_prompt = """Tu es un assistant specialise dans les applications metier francaises.
Tu reponds de maniere concise et factuelle aux questions sur:
- L'hebergement des applications
- Les technologies utilisees
- Les domaines metier
- Les statuts de production

Reponds UNIQUEMENT avec les informations demandees, sans details superflus."""

    modelfile_content = f"""FROM {gguf_file}

# Parametres de generation
PARAMETER temperature 0.7
PARAMETER top_p 0.9
PARAMETER top_k 40

# Prompt systeme
SYSTEM \"\"\"{system_prompt}\"\"\"
"""

    # Sauvegarder Modelfile temporaire
    modelfile_path = Path("Modelfile.dyag-export")
    with open(modelfile_path, 'w', encoding='utf-8') as f:
        f.write(modelfile_content)

    print(f"  Modelfile: {modelfile_path}")
    print(f"  Nom:       {model_name}")

    # Créer le modèle
    cmd = ["ollama", "create", model_name, "-f", str(modelfile_path)]

    print(f"\n  Commande: {' '.join(cmd)}")
    print("  (Cela peut prendre 1-2 minutes...)\n")

    try:
        subprocess.run(cmd, check=True)

        print(f"\n[OK] Modele Ollama cree: {model_name}")
        print(f"\nPour tester:")
        print(f"  ollama run {model_name}")

        # Supprimer Modelfile temporaire
        modelfile_path.unlink()

        return True

    except subprocess.CalledProcessError as e:
        print(f"\n[ERROR] Echec de la creation Ollama: {e}")
        return False


def export_to_gguf(
    model: str,
    base_model: str,
    output: str,
    quantize: Optional[str] = None,
    create_ollama: Optional[str] = None,
    llama_cpp_path: Optional[str] = None,
    system_prompt: Optional[str] = None
) -> int:
    """
    Exporte un modèle fine-tuné LoRA vers GGUF.

    Args:
        model: Chemin vers l'adapter LoRA
        base_model: Nom du modèle de base
        output: Fichier GGUF de sortie
        quantize: Type de quantification (Q4_K_M, Q5_K_M, etc.)
        create_ollama: Nom du modèle Ollama à créer
        llama_cpp_path: Chemin vers llama.cpp
        system_prompt: Prompt système personnalisé pour Ollama

    Returns:
        0 si succès, 1 sinon
    """
    print("=" * 70)
    print("DYAG - Export Modele Fine-Tune vers GGUF (Ollama)")
    print("=" * 70)
    print(f"\nModele LoRA:    {model}")
    print(f"Base model:     {base_model}")
    print(f"Output GGUF:    {output}")
    if quantize:
        print(f"Quantification: {quantize}")
    if create_ollama:
        print(f"Modele Ollama:  {create_ollama}")
    print()

    # Créer répertoires temporaires
    merged_path = "models/temp_merged"

    # Étape 1: Merge LoRA
    if not merge_lora_adapter(model, base_model, merged_path):
        return 1

    # Étape 2: Conversion GGUF
    output_path = Path(output)

    # Si quantification demandée, créer fichier FP16 temporaire
    if quantize:
        gguf_fp16 = output_path.with_suffix(".fp16.gguf")
    else:
        gguf_fp16 = output_path

    if not convert_to_gguf(merged_path, str(gguf_fp16), llama_cpp_path):
        return 1

    # Étape 3: Quantification (optionnelle)
    if quantize:
        if not quantize_gguf(str(gguf_fp16), str(output_path), quantize, llama_cpp_path or "../llama.cpp"):
            print(f"\n[WARNING] Quantification echouee, fichier FP16 disponible: {gguf_fp16}")
        else:
            # Supprimer fichier FP16 temporaire
            gguf_fp16.unlink()

    # Étape 4: Création modèle Ollama (optionnelle)
    if create_ollama:
        create_ollama_model(str(output_path), create_ollama, system_prompt)

    print("\n" + "=" * 70)
    print("EXPORT TERMINE")
    print("=" * 70)
    print(f"\nFichier GGUF: {output_path}")
    print(f"Taille:       {output_path.stat().st_size / (1024 * 1024):.1f} MB")

    if create_ollama:
        print(f"\nModele Ollama: {create_ollama}")
        print(f"  Lancer: ollama run {create_ollama}")
    else:
        print("\nPour utiliser avec Ollama:")
        print(f"  1. Creer Modelfile.dyag:")
        print(f"     FROM {output_path}")
        print(f"  2. ollama create mon-modele -f Modelfile.dyag")
        print(f"  3. ollama run mon-modele")

    print()

    return 0


def execute(args):
    """Exécute la commande export-to-gguf."""
    return export_to_gguf(
        model=args.model,
        base_model=args.base_model,
        output=args.output,
        quantize=args.quantize,
        create_ollama=args.create_ollama,
        llama_cpp_path=args.llama_cpp_path,
        system_prompt=args.system_prompt
    )


def register_export_to_gguf_command(subparsers):
    """Enregistre la commande export-to-gguf."""
    parser = subparsers.add_parser(
        'export-to-gguf',
        help='Exporte un modèle fine-tuné LoRA vers GGUF (Ollama)'
    )

    parser.add_argument(
        '--model',
        type=str,
        required=True,
        help='Chemin vers le modèle fine-tuné (adapter LoRA)'
    )
    parser.add_argument(
        '--base-model',
        type=str,
        required=True,
        help='Nom du modèle de base (ex: llama3.2:1b, tinyllama)'
    )
    parser.add_argument(
        '--output',
        type=str,
        required=True,
        help='Fichier GGUF de sortie (ex: models/dyag-mygusi.gguf)'
    )
    parser.add_argument(
        '--quantize',
        type=str,
        choices=['Q2_K', 'Q3_K_S', 'Q3_K_M', 'Q3_K_L', 'Q4_K_S', 'Q4_K_M', 'Q5_K_S', 'Q5_K_M', 'Q6_K', 'Q8_0'],
        help='Type de quantification (recommandé: Q4_K_M)'
    )
    parser.add_argument(
        '--create-ollama',
        type=str,
        help='Nom du modèle Ollama à créer (ex: dyag-mygusi:latest)'
    )
    parser.add_argument(
        '--llama-cpp-path',
        type=str,
        help='Chemin vers llama.cpp (auto-détecté si non spécifié)'
    )
    parser.add_argument(
        '--system-prompt',
        type=str,
        help='Prompt système personnalisé pour Ollama'
    )

    parser.set_defaults(func=execute)
