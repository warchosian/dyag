"""Module web pour l'interface RAG DYAG."""

__version__ = "1.0.0"
