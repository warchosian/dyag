"""
Command to analyze training data coverage for applications.

Analyzes which applications are present in training data and calculates coverage statistics.
"""

import json
import sys
import re
from pathlib import Path
from typing import Dict, List, Set, Tuple
from collections import defaultdict


def load_applications_from_json(file_path: Path) -> Dict[str, Dict]:
    """
    Charge les applications depuis un fichier JSON.

    Args:
        file_path: Chemin vers le fichier JSON

    Returns:
        Dictionnaire {nom_application: metadata}
    """
    with open(file_path, 'r', encoding='utf-8') as f:
        data = json.load(f)

    applications = {}

    def extract_app_from_dict(app: dict) -> tuple:
        """Extrait le nom et métadonnées d'un dict d'application."""
        # Essayer différentes clés pour le nom
        nom = None
        for key in ['Nom', 'nom', 'title']:
            if key in app:
                nom = app[key]
                break

        # Si c'est un chunk RAG, essayer metadata
        if not nom and 'metadata' in app and isinstance(app['metadata'], dict):
            nom = app['metadata'].get('nom') or app['metadata'].get('Nom')

        if not nom:
            return None, None

        nom = nom.strip()

        # Extraire les métadonnées avec différentes casses
        metadata = {
            'nom_original': nom,
            'nom_long': app.get('nom long') or app.get('Nom long', ''),
            'id': app.get('id') or app.get('Id', ''),
            'statut': app.get('statut si') or app.get('Statut SI', '')
        }

        return nom.lower(), metadata

    # Détection du format
    if isinstance(data, dict):
        # Format: {"key": [list of apps]}
        for key, apps in data.items():
            if isinstance(apps, list):
                for app in apps:
                    if isinstance(app, dict):
                        nom_key, metadata = extract_app_from_dict(app)
                        if nom_key:
                            applications[nom_key] = metadata
    elif isinstance(data, list):
        # Format: [list of apps] ou [list of RAG chunks]
        for app in data:
            if isinstance(app, dict):
                nom_key, metadata = extract_app_from_dict(app)
                if nom_key:
                    applications[nom_key] = metadata

    return applications


def load_applications_from_markdown(file_path: Path) -> Dict[str, Dict]:
    """
    Charge les applications depuis un fichier Markdown.

    Args:
        file_path: Chemin vers le fichier Markdown

    Returns:
        Dictionnaire {nom_application: metadata}
    """
    applications = {}

    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()

    # Chercher les patterns de titres d'applications
    # Pattern 1: ## Application: NomApp
    pattern1 = r'^##\s+(?:Application\s*:\s*)?(.+?)$'
    # Pattern 2: **Nom:** NomApp
    pattern2 = r'\*\*(?:Nom|Application)\s*:\*\*\s*(.+?)(?:\n|\||$)'

    for match in re.finditer(pattern1, content, re.MULTILINE):
        nom = match.group(1).strip()
        if nom and not nom.startswith('#'):
            applications[nom.lower()] = {
                'nom_original': nom,
                'nom_long': '',
                'id': '',
                'statut': ''
            }

    for match in re.finditer(pattern2, content, re.MULTILINE):
        nom = match.group(1).strip()
        if nom:
            applications[nom.lower()] = {
                'nom_original': nom,
                'nom_long': '',
                'id': '',
                'statut': ''
            }

    return applications


def load_applications(file_path: str) -> Dict[str, Dict]:
    """
    Charge les applications depuis un fichier (JSON ou Markdown).

    Args:
        file_path: Chemin vers le fichier

    Returns:
        Dictionnaire {nom_application: metadata}
    """
    path = Path(file_path)

    if not path.exists():
        raise FileNotFoundError(f"Fichier non trouvé: {file_path}")

    if path.suffix.lower() in ['.json', '.jsonl']:
        return load_applications_from_json(path)
    elif path.suffix.lower() in ['.md', '.markdown']:
        return load_applications_from_markdown(path)
    else:
        raise ValueError(f"Format de fichier non supporté: {path.suffix}")


def load_training_data(file_path: str) -> List[Dict]:
    """
    Charge les données de training depuis un fichier JSONL.

    Args:
        file_path: Chemin vers le fichier JSONL

    Returns:
        Liste des entrées de training
    """
    path = Path(file_path)

    if not path.exists():
        raise FileNotFoundError(f"Fichier non trouvé: {file_path}")

    training_data = []

    with open(path, 'r', encoding='utf-8') as f:
        for line_num, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue

            try:
                data = json.loads(line)
                training_data.append(data)
            except json.JSONDecodeError as e:
                print(f"Avertissement: Ligne {line_num} invalide: {e}", file=sys.stderr)

    return training_data


def extract_app_mentions(training_data: List[Dict]) -> Dict[str, List[int]]:
    """
    Extrait les mentions d'applications dans les données de training.

    Args:
        training_data: Liste des entrées de training

    Returns:
        Dictionnaire {nom_application_lower: [liste_indices]}
    """
    mentions = defaultdict(list)

    for idx, entry in enumerate(training_data):
        # Extraire tout le texte de l'entrée
        text_parts = []

        if 'messages' in entry:
            for msg in entry['messages']:
                if 'content' in msg:
                    text_parts.append(msg['content'])
        elif 'content' in entry:
            text_parts.append(entry['content'])

        full_text = ' '.join(text_parts).lower()

        # Chercher les mentions d'applications
        # On va chercher les mots/phrases qui pourraient être des noms d'apps
        # En utilisant des patterns simples
        words = re.findall(r'\b[\w\s\+\-]+\b', full_text)

        for word in words:
            word = word.strip()
            if word:
                mentions[word].append(idx)

    return mentions


def analyze_coverage(
    applications: Dict[str, Dict],
    training_data: List[Dict]
) -> Tuple[Dict[str, int], Set[str], Set[str]]:
    """
    Analyse la couverture des applications dans le training.

    Args:
        applications: Dictionnaire des applications
        training_data: Données de training

    Returns:
        (app_counts, covered_apps, uncovered_apps)
    """
    app_counts = defaultdict(int)
    covered_apps = set()

    for idx, entry in enumerate(training_data):
        # Extraire tout le texte
        text_parts = []

        if 'messages' in entry:
            for msg in entry['messages']:
                if 'content' in msg:
                    text_parts.append(msg['content'])
        elif 'content' in entry:
            text_parts.append(entry['content'])

        full_text = ' '.join(text_parts)

        # Chercher chaque application dans le texte
        for app_key, app_data in applications.items():
            nom_original = app_data['nom_original']

            # Recherche case-insensitive avec word boundaries
            pattern = r'\b' + re.escape(nom_original) + r'\b'

            if re.search(pattern, full_text, re.IGNORECASE):
                app_counts[nom_original] += 1
                covered_apps.add(app_key)

    uncovered_apps = set(applications.keys()) - covered_apps

    return app_counts, covered_apps, uncovered_apps


def print_report(
    applications: Dict[str, Dict],
    app_counts: Dict[str, int],
    covered_apps: Set[str],
    uncovered_apps: Set[str],
    total_training_entries: int
):
    """
    Affiche le rapport d'analyse.
    """
    print("=" * 80)
    print("ANALYSE DE COUVERTURE DU TRAINING")
    print("=" * 80)

    total_apps = len(applications)
    covered_count = len(covered_apps)
    coverage_pct = (covered_count / total_apps * 100) if total_apps > 0 else 0

    print(f"\nSTATISTIQUES GLOBALES")
    print("-" * 80)
    print(f"Applications totales       : {total_apps:,}")
    print(f"Applications couvertes     : {covered_count:,}")
    print(f"Applications non couvertes : {len(uncovered_apps):,}")
    print(f"Taux de couverture         : {coverage_pct:.1f}%")
    print(f"Entrées de training        : {total_training_entries:,}")

    # Top applications par nombre de mentions
    if app_counts:
        print(f"\nTOP 20 - APPLICATIONS LES PLUS MENTIONNÉES")
        print("-" * 80)
        print(f"{'Application':<40} {'Mentions':>15} {'% Training':>12}")
        print("-" * 80)

        sorted_apps = sorted(app_counts.items(), key=lambda x: x[1], reverse=True)
        for app_name, count in sorted_apps[:20]:
            pct = (count / total_training_entries * 100) if total_training_entries > 0 else 0
            print(f"{app_name:<40} {count:>15,} {pct:>11.2f}%")

    # Applications non couvertes
    if uncovered_apps:
        print(f"\nAPPLICATIONS NON COUVERTES ({len(uncovered_apps)})")
        print("-" * 80)

        uncovered_list = sorted([
            applications[app_key]['nom_original']
            for app_key in uncovered_apps
        ])

        # Afficher les 30 premières
        for i, app_name in enumerate(uncovered_list[:30], 1):
            print(f"{i:3d}. {app_name}")

        if len(uncovered_list) > 30:
            print(f"     ... et {len(uncovered_list) - 30} autres")

    # Statistiques par plage de mentions
    if app_counts:
        print(f"\nDISTRIBUTION DES MENTIONS")
        print("-" * 80)

        ranges = [
            (1, 1, "1 mention"),
            (2, 5, "2-5 mentions"),
            (6, 10, "6-10 mentions"),
            (11, 50, "11-50 mentions"),
            (51, 100, "51-100 mentions"),
            (101, float('inf'), "100+ mentions")
        ]

        for min_val, max_val, label in ranges:
            count = sum(1 for c in app_counts.values() if min_val <= c <= max_val)
            if count > 0:
                pct = (count / covered_count * 100) if covered_count > 0 else 0
                print(f"{label:<20} : {count:>6,} applications ({pct:>5.1f}%)")


def analyze_training_coverage(app_file: str, training_file: str) -> int:
    """
    Analyze training coverage for applications.

    Args:
        app_file: Path to applications file (JSON or Markdown)
        training_file: Path to training data file (JSONL)

    Returns:
        Exit code (0 for success, 1 for error)
    """
    # Fix encoding for Windows console
    if sys.platform == 'win32':
        import codecs
        sys.stdout = codecs.getwriter('utf-8')(sys.stdout.buffer, 'strict')
        sys.stderr = codecs.getwriter('utf-8')(sys.stderr.buffer, 'strict')

    print(f"\n[*] Chargement des fichiers...")
    print(f"    Applications : {app_file}")
    print(f"    Training     : {training_file}")

    try:
        # Charger les applications
        applications = load_applications(app_file)
        print(f"    [OK] {len(applications):,} applications chargées")

        # Charger les données de training
        training_data = load_training_data(training_file)
        print(f"    [OK] {len(training_data):,} entrées de training chargées")

        # Analyser la couverture
        print(f"\n[*] Analyse en cours...")
        app_counts, covered_apps, uncovered_apps = analyze_coverage(
            applications, training_data
        )

        # Afficher le rapport
        print_report(
            applications,
            app_counts,
            covered_apps,
            uncovered_apps,
            len(training_data)
        )

        print("\n" + "=" * 80)
        print("[OK] Analyse terminée avec succès")
        print("=" * 80)

        return 0

    except Exception as e:
        print(f"\n[ERREUR] {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        return 1


def register_analyze_training_command(subparsers):
    """Register the analyze-training command."""
    parser = subparsers.add_parser(
        'analyze-training',
        help='Analyze training data coverage for applications',
        description='Compare applications file with training data to calculate coverage statistics'
    )

    parser.add_argument(
        'applications',
        type=str,
        help='Applications file (JSON or Markdown)'
    )

    parser.add_argument(
        'training',
        type=str,
        help='Training data file (JSONL format)'
    )

    def execute(args):
        return analyze_training_coverage(args.applications, args.training)

    parser.set_defaults(func=execute)


if __name__ == '__main__':
    # Allow running as standalone script
    import argparse
    parser = argparse.ArgumentParser(
        description="Analyze training data coverage for applications"
    )
    parser.add_argument('applications', help='Applications file')
    parser.add_argument('training', help='Training data file')
    args = parser.parse_args()

    sys.exit(analyze_training_coverage(args.applications, args.training))
