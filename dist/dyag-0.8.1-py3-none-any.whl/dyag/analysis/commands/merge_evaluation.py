#!/usr/bin/env python3
"""
Commande merge-evaluation pour fusionner plusieurs résultats d'évaluation RAG.

Fait partie du package dyag.
"""
import json
import sys
from pathlib import Path
from datetime import datetime
import glob


def merge_evaluation_results(batch_files, output_file, verbose=False):
    """
    Fusionne les résultats de plusieurs batches d'évaluation RAG.

    Args:
        batch_files: Liste de fichiers JSON à fusionner
        output_file: Fichier de sortie pour résultats fusionnés
        verbose: Afficher progression détaillée

    Returns:
        Dictionnaire avec statistiques globales ou None si erreur
    """
    if not batch_files:
        print("❌ No batch files provided")
        return None

    all_results = []
    total_stats = {
        'total': 0,
        'successful': 0,
        'failed': 0,
        'total_time': 0.0,
        'total_tokens': 0
    }

    if verbose:
        print(f"\nMerging {len(batch_files)} batch files...")
        print("=" * 60)

    for i, batch_file in enumerate(batch_files, 1):
        batch_path = Path(batch_file)
        if not batch_path.exists():
            if verbose:
                print(f"⚠️  Batch {i}: File not found: {batch_file}")
            continue

        if verbose:
            print(f"[{i}/{len(batch_files)}] {batch_path.name}...", end=" ")

        try:
            with open(batch_path, 'r', encoding='utf-8') as f:
                data = json.load(f)

            # Fusionner résultats
            results = data.get('results', [])
            all_results.extend(results)

            # Additionner statistiques
            stats = data.get('statistics', {})
            total_stats['total'] += stats.get('total', 0)
            total_stats['successful'] += stats.get('successful', 0)
            total_stats['failed'] += stats.get('failed', 0)
            total_stats['total_time'] += stats.get('total_time', 0.0)
            total_stats['total_tokens'] += stats.get('total_tokens', 0)

            if verbose:
                print(f"✓ {len(results)} questions")

        except json.JSONDecodeError as e:
            if verbose:
                print(f"❌ Invalid JSON: {e}")
            continue
        except Exception as e:
            if verbose:
                print(f"❌ Error: {e}")
            continue

    if not all_results:
        print("\n❌ No results to merge")
        return None

    if verbose:
        print("=" * 60)

    # Récupérer metadata du premier batch
    first_batch_meta = {}
    if batch_files:
        try:
            with open(batch_files[0], 'r', encoding='utf-8') as f:
                first_data = json.load(f)
                first_batch_meta = first_data.get('metadata', {})
        except:
            pass

    # Calculer success_rate
    if total_stats['total'] > 0:
        total_stats['success_rate'] = (total_stats['successful'] / total_stats['total']) * 100
    else:
        total_stats['success_rate'] = 0.0

    # Créer résultat fusionné
    merged = {
        'metadata': {
            **first_batch_meta,
            'merge_date': datetime.now().isoformat(),
            'source_batches': [str(Path(f).name) for f in batch_files],
            'total_batches': len(batch_files),
            'merged': True
        },
        'statistics': total_stats,
        'results': all_results
    }

    # Sauvegarder
    output_path = Path(output_file)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(merged, f, ensure_ascii=False, indent=2)

    # Afficher résumé
    print(f"\n✓ Successfully merged {len(batch_files)} batches")
    print(f"  Total questions: {total_stats['total']}")
    print(f"  Success rate: {total_stats['success_rate']:.1f}%")
    print(f"  Total time: {total_stats['total_time']:.1f}s ({total_stats['total_time']/3600:.1f}h)")
    print(f"  Total tokens: {total_stats['total_tokens']:,}")
    print(f"\n✓ Output saved to: {output_path}")

    return merged


def run_merge_evaluation(args):
    """Point d'entrée pour la commande CLI."""
    # Collecter fichiers
    batch_files = []

    if args.pattern:
        # Utiliser pattern glob
        batch_files = sorted(glob.glob(args.pattern))
        if not batch_files:
            print(f"❌ No files found matching pattern: {args.pattern}")
            return 1

    elif args.files:
        # Utiliser fichiers spécifiés (expander wildcards)
        for file_pattern in args.files:
            if '*' in file_pattern or '?' in file_pattern:
                batch_files.extend(sorted(glob.glob(file_pattern)))
            else:
                batch_files.append(file_pattern)

        if not batch_files:
            print("❌ No batch files found")
            return 1

    else:
        # Défaut: chercher tous les batch dans evaluation/
        default_pattern = "evaluation/results_*_batch*.json"
        batch_files = sorted(glob.glob(default_pattern))

        if not batch_files:
            print(f"❌ No batch files found with default pattern: {default_pattern}")
            print("\nTip: Specify files or use --pattern option")
            return 1

    # Fusionner
    result = merge_evaluation_results(
        batch_files,
        args.output,
        verbose=args.verbose
    )

    return 0 if result else 1


def main():
    """Point d'entrée pour exécution standalone."""
    import argparse

    parser = argparse.ArgumentParser(
        description="Fusionner plusieurs fichiers de résultats d'évaluation RAG",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Merge all batches in evaluation/
  dyag merge-evaluation

  # Merge specific pattern
  dyag merge-evaluation --pattern "evaluation/results_1008_batch*.json"

  # Specify output file
  dyag merge-evaluation --output final.json batch1.json batch2.json

  # Merge with verbose output
  dyag merge-evaluation --verbose --pattern "results_*.json"
        """
    )

    parser.add_argument(
        'files',
        nargs='*',
        help='Batch files to merge (supports wildcards)'
    )

    parser.add_argument(
        '--output', '-o',
        default='evaluation/results_merged.json',
        help='Output file (default: evaluation/results_merged.json)'
    )

    parser.add_argument(
        '--pattern', '-p',
        help='Glob pattern for auto-discovery (e.g., "evaluation/results_*_batch*.json")'
    )

    parser.add_argument(
        '--verbose', '-v',
        action='store_true',
        help='Show detailed progress'
    )

    args = parser.parse_args()
    return run_merge_evaluation(args)


if __name__ == "__main__":
    sys.exit(main())
