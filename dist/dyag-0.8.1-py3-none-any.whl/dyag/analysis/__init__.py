"""
Module Analysis - DYAG

Analyse de données et génération de rapports.
"""

# Les commandes sont dans le sous-module commands
# Usage: from dyag.analysis.commands.analyze_training import analyze_training_coverage
