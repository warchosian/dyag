"""
Commande test-rag : Test rapide du système RAG.

Ce module permet de tester rapidement le RAG sans problèmes d'encodage Unicode.
Supporte deux formats de sortie : texte simple et JSON.
"""

import sys
import io
import json
import time
from pathlib import Path
from typing import Dict, Optional

# Fixer l'encodage UTF-8 pour Windows
if sys.platform == 'win32' and __name__ == '__main__':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')

from dyag.rag.core.retriever import RAGQuerySystem


def test_rag_question(
    rag: RAGQuerySystem,
    question: str,
    n_chunks: int = 5,
    output_format: str = 'text',
    show_chunks: bool = False,
    verbose: bool = False
) -> Dict:
    """
    Teste le RAG avec une question et retourne le résultat formaté.

    Args:
        rag: Système RAG initialisé
        question: Question à poser
        n_chunks: Nombre de chunks de contexte
        output_format: Format de sortie ('text' ou 'json')
        show_chunks: Afficher le contenu des chunks
        verbose: Affichage détaillé

    Returns:
        Résultat formaté selon le format demandé
    """
    # Recherche
    search_start = time.time()
    chunks = rag.search_chunks(question, n_results=n_chunks)
    search_time = time.time() - search_start

    if not chunks:
        return {
            'question': question,
            'answer': "Aucun chunk pertinent trouve pour cette question.",
            'sources': [],
            'search_time': search_time,
            'answer_time': 0,
            'total_time': search_time,
            'tokens': 0
        }

    # Génération de la réponse
    answer_start = time.time()
    result = rag.generate_answer(question, chunks)
    answer_time = time.time() - answer_start

    # Préparer les sources avec scores
    sources = []
    for chunk in chunks:
        sources.append({
            'id': chunk['id'],
            'score': round(1.0 - chunk['distance'], 2),  # Convertir distance en similarité
            'content': chunk['content'] if show_chunks else None
        })

    # Résultat complet
    output = {
        'question': question,
        'answer': result['answer'],
        'sources': sources,
        'search_time': round(search_time, 2),
        'answer_time': round(answer_time, 2),
        'total_time': round(search_time + answer_time, 2),
        'tokens': result['tokens_used']
    }

    return output


def format_output_text(result: Dict, show_chunks: bool = False) -> str:
    """
    Formate le résultat en texte simple (sans emojis).

    Args:
        result: Résultat de test_rag_question
        show_chunks: Afficher le contenu des chunks

    Returns:
        Texte formaté
    """
    lines = []

    lines.append(f"[Question] {result['question']}")
    lines.append("")

    lines.append(f"[Recherche] {len(result['sources'])} chunks pertinents trouves ({result['search_time']}s)")
    lines.append("")

    lines.append(f"[Reponse] ({result['answer_time']}s, {result['tokens']} tokens)")
    lines.append(result['answer'])
    lines.append("")

    lines.append("[Sources]")
    for source in result['sources']:
        lines.append(f"- {source['id']} (score: {source['score']})")
        if show_chunks and source.get('content'):
            # Afficher les 200 premiers caractères du chunk
            content_preview = source['content'][:200] + "..." if len(source['content']) > 200 else source['content']
            lines.append(f"  {content_preview}")

    lines.append("")
    lines.append(f"[Temps total] {result['total_time']}s")

    return "\n".join(lines)


def format_output_json(result: Dict, show_chunks: bool = False) -> str:
    """
    Formate le résultat en JSON.

    Args:
        result: Résultat de test_rag_question
        show_chunks: Inclure le contenu des chunks

    Returns:
        JSON formaté
    """
    # Nettoyer les chunks si on ne veut pas afficher le contenu
    if not show_chunks:
        for source in result['sources']:
            if 'content' in source:
                del source['content']

    return json.dumps(result, ensure_ascii=False, indent=2)


def execute(args):
    """Exécute la commande test-rag."""

    # Initialiser le RAG
    try:
        if args.verbose:
            print("[INFO] Initialisation du systeme RAG...")

        rag = RAGQuerySystem(
            chroma_path=args.chroma_path,
            collection_name=args.collection,
            embedding_model=args.embedding_model,
            timeout=args.timeout
        )

        if args.verbose:
            stats = rag.get_stats()
            print(f"[INFO] Collection: {stats['collection_name']}")
            print(f"[INFO] Chunks indexes: {stats['total_chunks']}")
            print(f"[INFO] Modele LLM: {stats['llm_model']}")
            print()

    except Exception as e:
        print(f"[ERROR] Erreur d'initialisation du RAG: {e}")
        return 1

    # Mode question directe
    if args.question:
        try:
            result = test_rag_question(
                rag=rag,
                question=args.question,
                n_chunks=args.n_chunks,
                output_format=args.format,
                show_chunks=args.show_chunks,
                verbose=args.verbose
            )

            # Afficher selon le format
            if args.format == 'json':
                print(format_output_json(result, show_chunks=args.show_chunks))
            else:
                print(format_output_text(result, show_chunks=args.show_chunks))

            return 0

        except Exception as e:
            print(f"[ERROR] Erreur lors du test: {e}")
            if args.verbose:
                import traceback
                traceback.print_exc()
            return 1

    # Mode interactif
    print("=" * 60)
    print("Mode interactif - Posez vos questions (Ctrl+C pour quitter)")
    print("=" * 60)
    print()

    while True:
        try:
            question = input("[Question] ")

            if not question.strip():
                continue

            result = test_rag_question(
                rag=rag,
                question=question,
                n_chunks=args.n_chunks,
                output_format=args.format,
                show_chunks=args.show_chunks,
                verbose=args.verbose
            )

            print()
            if args.format == 'json':
                print(format_output_json(result, show_chunks=args.show_chunks))
            else:
                print(format_output_text(result, show_chunks=args.show_chunks))
            print()

        except KeyboardInterrupt:
            print("\n\nAu revoir!")
            break
        except Exception as e:
            print(f"\n[ERROR] {e}")
            if args.verbose:
                import traceback
                traceback.print_exc()

    return 0


def register_test_rag_command(subparsers):
    """Enregistre la commande test-rag."""
    parser = subparsers.add_parser(
        'test-rag',
        help='Teste rapidement le RAG (sans emojis, output JSON/text)'
    )

    parser.add_argument(
        '--collection',
        type=str,
        required=True,
        help='Nom de la collection ChromaDB'
    )
    parser.add_argument(
        '--question',
        type=str,
        help='Question a poser (si absent: mode interactif)'
    )
    parser.add_argument(
        '--n-chunks',
        type=int,
        default=5,
        help='Nombre de chunks de contexte (defaut: 5)'
    )
    parser.add_argument(
        '--format',
        type=str,
        choices=['text', 'json'],
        default='text',
        help='Format de sortie: text ou json (defaut: text)'
    )
    parser.add_argument(
        '--show-chunks',
        action='store_true',
        help='Afficher le contenu des chunks dans la sortie'
    )
    parser.add_argument(
        '--chroma-path',
        type=str,
        default='./chroma_db',
        help='Chemin vers ChromaDB (defaut: ./chroma_db)'
    )
    parser.add_argument(
        '--embedding-model',
        type=str,
        default='all-MiniLM-L6-v2',
        help='Modele d\'embedding (defaut: all-MiniLM-L6-v2)'
    )
    parser.add_argument(
        '--timeout',
        type=int,
        help='Timeout en secondes pour Ollama'
    )
    parser.add_argument(
        '-v', '--verbose',
        action='store_true',
        help='Affichage detaille'
    )

    parser.set_defaults(func=execute)
