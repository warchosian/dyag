"""
Commande d'évaluation du système RAG.

Teste le système RAG avec des questions de référence et compare
les réponses avec les réponses attendues.
"""

import json
import sys
import io
from pathlib import Path
from typing import List, Dict
import time
from datetime import datetime
import numpy as np
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity

# Fixer l'encodage UTF-8 pour Windows (seulement si exécuté comme script principal)
if sys.platform == 'win32' and __name__ == '__main__':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')

from dyag.rag.core.retriever import RAGQuerySystem

# Modèle d'embedding pour calcul de similarité (léger et rapide)
_similarity_model = None

def get_similarity_model():
    """Charge le modèle de similarité (lazy loading)."""
    global _similarity_model
    if _similarity_model is None:
        print("[INFO] Chargement du modele de similarite (all-MiniLM-L6-v2)...")
        _similarity_model = SentenceTransformer('all-MiniLM-L6-v2')
    return _similarity_model


def calculate_similarity(answer: str, expected: str) -> Dict:
    """
    Calcule la similarité entre la réponse obtenue et la réponse attendue.

    Args:
        answer: Réponse générée par le RAG
        expected: Réponse attendue

    Returns:
        Dict avec: similarity (float 0-1), is_correct (bool), exact_match (bool)
    """
    # Match exact (sensible à la casse)
    exact_match = answer.strip().lower() == expected.strip().lower()

    # Similarité sémantique via embeddings
    model = get_similarity_model()
    embeddings = model.encode([answer, expected])
    similarity = cosine_similarity([embeddings[0]], [embeddings[1]])[0][0]

    # Critère de correction: similarité >= 70% ou match exact
    is_correct = similarity >= 0.70 or exact_match

    return {
        'similarity': float(similarity),
        'is_correct': bool(is_correct),
        'exact_match': bool(exact_match)
    }


def extract_app_name_from_question(question: str) -> str | None:
    """
    Extrait le nom de l'application d'une question.

    Args:
        question: Question posée

    Returns:
        Nom de l'application ou None si non trouvé
    """
    # Liste des applications connues (à étendre au besoin)
    known_apps = [
        "6Tzen", "ACAPE", "Action Cœur de Ville", "Acceslibre", "ADES",
        "ADAU", "Access Libre", "Adapt.sh", "GIDAF", "WikiSI"
    ]

    question_lower = question.lower()
    for app in known_apps:
        if app.lower() in question_lower:
            return app

    return None


def load_dataset(dataset_path: str) -> List[Dict]:
    """
    Charge un dataset JSONL de questions/réponses.

    Supporte deux formats :
    1. Format "messages" : {"messages": [{"role": "user", "content": "..."}]}
    2. Format direct : {"question": "...", "expected_answer": "..."}

    Args:
        dataset_path: Chemin vers le fichier JSONL

    Returns:
        Liste de {question, expected_answer, system_prompt}
    """
    print(f"Chargement du dataset: {dataset_path}")

    questions = []
    with open(dataset_path, 'r', encoding='utf-8') as f:
        for line_num, line in enumerate(f, 1):
            try:
                data = json.loads(line.strip())

                # Format 1 : messages avec roles
                if 'messages' in data:
                    messages = data['messages']
                    user_msg = next((m for m in messages if m['role'] == 'user'), None)
                    assistant_msg = next((m for m in messages if m['role'] == 'assistant'), None)
                    system_msg = next((m for m in messages if m['role'] == 'system'), None)

                    if user_msg and assistant_msg:
                        questions.append({
                            'question': user_msg['content'],
                            'expected_answer': assistant_msg['content'],
                            'system_prompt': system_msg['content'] if system_msg else None,
                            'line_num': line_num
                        })

                # Format 2 : question/expected_answer direct
                elif 'question' in data and 'expected_answer' in data:
                    questions.append({
                        'question': data['question'],
                        'expected_answer': data['expected_answer'],
                        'system_prompt': None,
                        'line_num': line_num
                    })

            except Exception as e:
                print(f"Erreur ligne {line_num}: {e}")
                continue

    print(f"[OK] {len(questions)} questions chargées\n")
    return questions


def evaluate_rag(
    rag: RAGQuerySystem,
    questions: List[Dict],
    n_chunks: int = 5,
    max_questions: int = None,
    output_file: str = None,
    use_reranking: bool = False
) -> Dict:
    """
    Évalue le système RAG sur un ensemble de questions.

    Args:
        rag: Système RAG initialisé
        questions: Liste de questions avec réponses attendues
        n_chunks: Nombre de chunks de contexte
        max_questions: Nombre max de questions à tester (None = toutes)
        output_file: Fichier JSON pour sauvegarder les résultats détaillés

    Returns:
        Statistiques d'évaluation
    """
    if max_questions:
        questions = questions[:max_questions]

    llm_model_name = rag.llm_provider.get_model_name()

    print("=" * 80)
    print(f"EVALUATION RAG - {len(questions)} questions")
    print("=" * 80)
    print(f"[LLM] Modele: {llm_model_name}")
    print(f"[DATA] Chunks par question: {n_chunks}")
    print(f"[DB] Collection: {rag.collection.name}")
    print(f"[FILTER] Filtrage active (extraction automatique de app_name)")
    if use_reranking:
        print(f"[RERANK] Reranking active avec CrossEncoder")
    print("=" * 80)
    print()

    results = []
    total_time = 0
    total_tokens = 0

    for i, q in enumerate(questions, 1):
        question = q['question']
        expected = q['expected_answer']

        print(f"\n[{i}/{len(questions)}] {question}")
        print("-" * 80)

        try:
            start_time = time.time()

            # Extraire le nom de l'application et activer le filtrage
            app_name = extract_app_name_from_question(question)
            filter_metadata = {"app_name": app_name} if app_name else None

            result = rag.ask(question, n_chunks=n_chunks, filter_metadata=filter_metadata, use_reranking=use_reranking)
            elapsed = time.time() - start_time

            answer = result['answer']
            tokens = result.get('tokens_used', 0)
            sources = result.get('sources', [])

            # Calculer similarité
            similarity_metrics = calculate_similarity(answer, expected)

            # Afficher réponse
            print(f"\n[OK] Réponse ({elapsed:.1f}s, {tokens} tokens):")
            print(answer[:300] + "..." if len(answer) > 300 else answer)

            print(f"\n[Expected]:")
            print(expected[:300] + "..." if len(expected) > 300 else expected)

            print(f"\n[Similarity]: {similarity_metrics['similarity']:.1%} | Correct: {similarity_metrics['is_correct']} | Exact: {similarity_metrics['exact_match']}")
            print(f"[Sources]: {', '.join(sources[:3])}...")

            # Enregistrer résultat
            results.append({
                'question': question,
                'answer': answer,
                'expected': expected,
                'sources': sources,
                'tokens': tokens,
                'time': elapsed,
                'success': True,
                'error': None,
                'similarity': similarity_metrics['similarity'],
                'is_correct': similarity_metrics['is_correct'],
                'exact_match': similarity_metrics['exact_match']
            })

            total_time += elapsed
            total_tokens += tokens

        except Exception as e:
            print(f"\n[ERROR] Erreur: {e}")
            results.append({
                'question': question,
                'answer': None,
                'expected': expected,
                'sources': [],
                'tokens': 0,
                'time': 0,
                'success': False,
                'error': str(e),
                'similarity': 0.0,
                'is_correct': False,
                'exact_match': False
            })

    # Statistiques
    print("\n" + "=" * 80)
    print("RÉSULTATS")
    print("=" * 80)

    successful = sum(1 for r in results if r['success'])
    failed = len(results) - successful

    print(f"\nQuestions traitées: {len(results)}")
    print(f"  [OK] Succès: {successful} ({successful/len(results)*100:.1f}%)")
    print(f"  [ERR] Échecs: {failed} ({failed/len(results)*100:.1f}%)")

    # Statistiques de similarité
    if successful > 0:
        correct_answers = sum(1 for r in results if r.get('is_correct', False))
        exact_matches = sum(1 for r in results if r.get('exact_match', False))
        avg_similarity = sum(r.get('similarity', 0.0) for r in results if r['success']) / successful

        print(f"\nQualité des réponses:")
        print(f"  [CORRECT] Réponses correctes (>70% similarité): {correct_answers} ({correct_answers/successful*100:.1f}%)")
        print(f"  [EXACT] Matchs exacts: {exact_matches} ({exact_matches/successful*100:.1f}%)")
        print(f"  [SIMILARITY] Similarité moyenne: {avg_similarity:.1%}")

    if successful > 0:
        avg_time = total_time / successful
        avg_tokens = total_tokens / successful
        print(f"\nPerformance moyenne:")
        print(f"  Temps: {avg_time:.1f}s")
        print(f"  Tokens: {avg_tokens:.0f}")

    print(f"\nTemps total: {total_time:.1f}s ({total_time/60:.1f} min)")
    print(f"Tokens total: {total_tokens}")

    # Sauvegarder résultats détaillés
    if output_file:
        # Calculer métriques globales de similarité
        if successful > 0:
            correct_answers = sum(1 for r in results if r.get('is_correct', False))
            exact_matches = sum(1 for r in results if r.get('exact_match', False))
            avg_similarity = sum(r.get('similarity', 0.0) for r in results if r['success']) / successful
        else:
            correct_answers = 0
            exact_matches = 0
            avg_similarity = 0.0

        output_path = Path(output_file)
        report = {
            'metadata': {
                'timestamp': datetime.now().isoformat(),
                'llm_model': llm_model_name,
                'embedding_model': rag.embedding_model.get_sentence_embedding_dimension(),
                'collection_name': rag.collection.name,
                'n_chunks': n_chunks,
                'filtering_enabled': True,  # filtrage app_name activé
                'reranking_enabled': use_reranking,
                'total_questions': len(results),
                'successful': successful,
                'failed': failed,
                'total_time': total_time,
                'total_tokens': total_tokens,
                'correct_answers': correct_answers,
                'exact_matches': exact_matches,
                'average_similarity': avg_similarity,
                'accuracy_percent': (correct_answers / successful * 100) if successful > 0 else 0.0
            },
            'results': results
        }

        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(report, f, ensure_ascii=False, indent=2)

        print(f"\n[OK] Résultats sauvegardés: {output_file}")

    print("=" * 80)

    return {
        'total': len(results),
        'successful': successful,
        'failed': failed,
        'total_time': total_time,
        'total_tokens': total_tokens,
        'results': results
    }


def execute(args):
    """Exécute la commande evaluate-rag."""
    # Vérifier dataset
    dataset_path = Path(args.dataset)
    if not dataset_path.exists():
        print(f"[ERROR] Dataset introuvable: {args.dataset}")
        return 1

    # Charger questions
    questions = load_dataset(args.dataset)
    if not questions:
        print("[ERROR] Aucune question trouvée dans le dataset")
        return 1

    # Initialiser RAG
    print("Initialisation du système RAG...")
    try:
        rag = RAGQuerySystem(
            chroma_path=args.chroma_path,
            collection_name=args.collection,
            embedding_model=args.embedding_model,
            timeout=args.timeout,
            llm_model=args.llm_model if hasattr(args, 'llm_model') else None
        )
    except Exception as e:
        print(f"[ERROR] Erreur d'initialisation du RAG: {e}")
        return 1

    # Évaluer
    stats = evaluate_rag(
        rag=rag,
        questions=questions,
        n_chunks=args.n_chunks,
        max_questions=args.max_questions,
        output_file=args.output,
        use_reranking=args.use_reranking
    )

    # Code de sortie selon résultats
    return 0 if stats['failed'] == 0 else 1


def register_evaluate_rag_command(subparsers):
    """Enregistre la commande evaluate-rag."""
    parser = subparsers.add_parser(
        'evaluate-rag',
        help='Évalue le système RAG avec un dataset de questions/réponses'
    )

    parser.add_argument(
        'dataset',
        type=str,
        help='Chemin vers le dataset JSONL (ex: data/finetuning/dataset_mygusi_train-100.jsonl)'
    )
    parser.add_argument(
        '--n-chunks',
        type=int,
        default=5,
        help='Nombre de chunks de contexte (défaut: 5)'
    )
    parser.add_argument(
        '--max-questions',
        type=int,
        help='Nombre max de questions à tester (défaut: toutes)'
    )
    parser.add_argument(
        '--output',
        type=str,
        help='Fichier JSON pour sauvegarder les résultats détaillés'
    )
    parser.add_argument(
        '--collection',
        type=str,
        default='applications',
        help='Nom de la collection ChromaDB (défaut: applications)'
    )
    parser.add_argument(
        '--chroma-path',
        type=str,
        default='./chroma_db',
        help='Chemin vers ChromaDB (défaut: ./chroma_db)'
    )
    parser.add_argument(
        '--embedding-model',
        type=str,
        default='all-MiniLM-L6-v2',
        help='Modèle d\'embedding (défaut: all-MiniLM-L6-v2)'
    )
    parser.add_argument(
        '--timeout',
        type=int,
        help='Timeout en secondes pour Ollama'
    )
    parser.add_argument(
        '--llm-model',
        type=str,
        help='Modèle LLM à utiliser (ex: llama3.2:1b, qwen2.5:1.5b). Si non spécifié, utilise LLM_MODEL du .env'
    )
    parser.add_argument(
        '--use-reranking',
        action='store_true',
        help='Activer le reranking avec CrossEncoder'
    )

    parser.set_defaults(func=execute)
