"""
Commande de comparaison de résultats d'évaluation RAG.

Compare deux fichiers de résultats d'évaluation et génère un rapport
détaillé des améliorations.
"""

from dyag.rag.core.comparison import compare_results


def execute(args):
    """Exécute la commande compare-rag."""
    return compare_results(args.baseline, args.improved)


def register_compare_rag_command(subparsers):
    """Enregistre la commande compare-rag."""
    parser = subparsers.add_parser(
        'compare-rag',
        help='Compare deux fichiers de résultats d\'évaluation RAG'
    )

    parser.add_argument(
        'baseline',
        type=str,
        help='Fichier de résultats baseline (avant améliorations)'
    )
    parser.add_argument(
        'improved',
        type=str,
        help='Fichier de résultats améliorés (après améliorations)'
    )

    parser.set_defaults(func=execute)
