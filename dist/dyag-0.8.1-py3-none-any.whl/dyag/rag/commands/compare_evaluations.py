"""
Commande pour comparer plusieurs évaluations.

Permet de comparer les résultats sans réexécuter les évaluations.
"""

import json
import sys
from pathlib import Path
from typing import Dict, List


def load_evaluation(file_path: str) -> Dict:
    """Charge un fichier de résultats d'évaluation."""
    with open(file_path, 'r', encoding='utf-8') as f:
        return json.load(f)


def generate_comparison_table(evaluations: List[Dict], names: List[str]) -> str:
    """Génère un tableau comparatif des évaluations."""
    lines = [
        "=" * 100,
        "COMPARAISON DES EVALUATIONS",
        "=" * 100,
        ""
    ]

    # En-tete du tableau
    header = f"{'Metrique':<40} | " + " | ".join(f"{name:>20}" for name in names)
    separator = "-" * len(header)

    lines.append(header)
    lines.append(separator)

    # Extraire métadonnées
    metadatas = [eval_data.get('metadata', {}) for eval_data in evaluations]

    # Metriques de base
    metrics = [
        ("Modele LLM", lambda m: m.get('llm_model', 'N/A')),
        ("Collection", lambda m: m.get('collection_name', 'N/A')),
        ("Chunks", lambda m: str(m.get('n_chunks', 'N/A'))),
        ("Questions totales", lambda m: str(m.get('total_questions', 0))),
        ("Succes", lambda m: str(m.get('successful', 0))),
        ("Echecs", lambda m: str(m.get('failed', 0))),
        ("", None),  # Ligne vide
        ("Reponses correctes (>=70%)", lambda m: f"{m.get('correct_answers', 0)} ({m.get('accuracy_percent', 0):.1f}%)"),
        ("Matchs exacts", lambda m: str(m.get('exact_matches', 0))),
        ("Similarite moyenne", lambda m: f"{m.get('average_similarity', 0):.1%}"),
        ("", None),  # Ligne vide
        ("Temps total (min)", lambda m: f"{m.get('total_time', 0)/60:.1f}"),
        ("Tokens total", lambda m: str(m.get('total_tokens', 0))),
        ("Temps moyen/question (s)", lambda m: f"{m.get('total_time', 0)/max(m.get('successful', 1), 1):.1f}"),
        ("Tokens moyen/question", lambda m: f"{m.get('total_tokens', 0)//max(m.get('successful', 1), 1)}"),
    ]

    for metric_name, metric_func in metrics:
        if metric_func is None:
            lines.append("")
            continue

        values = [metric_func(m) for m in metadatas]
        row = f"{metric_name:<40} | " + " | ".join(f"{v:>20}" for v in values)
        lines.append(row)

    lines.append(separator)

    # Identifier le gagnant pour chaque metrique cle
    lines.append("")
    lines.append("GAGNANTS")
    lines.append(separator)

    # Similarite moyenne (plus haute = meilleure)
    similarities = [m.get('average_similarity', 0) for m in metadatas]
    best_sim_idx = similarities.index(max(similarities))
    lines.append(f"{'Meilleure similarite':<40} | {names[best_sim_idx]} ({max(similarities):.1%})")

    # Precision (plus haute = meilleure)
    accuracies = [m.get('accuracy_percent', 0) for m in metadatas]
    best_acc_idx = accuracies.index(max(accuracies))
    lines.append(f"{'Meilleure precision':<40} | {names[best_acc_idx]} ({max(accuracies):.1f}%)")

    # Vitesse (plus rapide = meilleure)
    times = [m.get('total_time', float('inf')) for m in metadatas]
    fastest_idx = times.index(min(times))
    lines.append(f"{'Plus rapide':<40} | {names[fastest_idx]} ({min(times)/60:.1f} min)")

    lines.append("=" * 100)

    return "\n".join(lines)


def generate_question_by_question_comparison(evaluations: List[Dict], names: List[str]) -> str:
    """Génère une comparaison question par question."""
    lines = [
        "",
        "=" * 100,
        "COMPARAISON QUESTION PAR QUESTION",
        "=" * 100,
        ""
    ]

    # Récupérer les résultats
    results_lists = [eval_data.get('results', []) for eval_data in evaluations]

    # Vérifier que toutes les évaluations ont le même nombre de questions
    num_questions = min(len(r) for r in results_lists)

    for i in range(num_questions):
        question = results_lists[0][i].get('question', f'Question {i+1}')
        lines.append(f"[Q{i+1}] {question}")
        lines.append("-" * 100)

        # Comparer les réponses
        for j, (results, name) in enumerate(zip(results_lists, names)):
            result = results[i]
            answer = result.get('answer', 'N/A')
            similarity = result.get('similarity', 0)
            is_correct = result.get('is_correct', False)

            # Tronquer réponse
            answer_display = answer[:100] + "..." if len(answer) > 100 else answer

            status = "[OK]" if is_correct else "[LOW]"
            lines.append(f"{status} {name:<20} | Sim: {similarity:>6.1%} | {answer_display}")

        # Identifier le gagnant
        similarities = [r[i].get('similarity', 0) for r in results_lists]
        winner_idx = similarities.index(max(similarities))
        winner_diff = max(similarities) - min(similarities)

        if winner_diff > 0.01:  # Différence significative
            lines.append(f"    [WIN] {names[winner_idx]} (+{winner_diff:.1%})")

        lines.append("")

    return "\n".join(lines)


def compare_evaluations(
    files: List[str],
    names: List[str] = None,
    detailed: bool = False,
    output: str = None
):
    """
    Compare plusieurs évaluations.

    Args:
        files: Liste de fichiers JSON de résultats
        names: Noms personnalisés pour les évaluations
        detailed: Afficher comparaison question par question
        output: Fichier de sortie (Markdown)
    """
    # Charger les évaluations
    evaluations = []
    for file_path in files:
        path = Path(file_path)
        if not path.exists():
            print(f"[ERROR] Fichier introuvable: {file_path}")
            return 1

        print(f"[INFO] Chargement: {file_path}")
        evaluations.append(load_evaluation(file_path))

    # Générer noms par défaut
    if not names:
        names = [f"Eval {i+1}" for i in range(len(files))]
    elif len(names) < len(files):
        names.extend([f"Eval {i+1}" for i in range(len(names), len(files))])

    # Générer comparaison
    comparison = generate_comparison_table(evaluations, names)
    print("\n" + comparison)

    if detailed:
        detailed_comparison = generate_question_by_question_comparison(evaluations, names)
        print(detailed_comparison)

    # Sauvegarder si demandé
    if output:
        output_path = Path(output)
        content = f"# Rapport de Comparaison d'Évaluations\n\n"
        content += f"**Fichiers comparés:**\n"
        for name, file_path in zip(names, files):
            content += f"- {name}: `{file_path}`\n"
        content += "\n"
        content += comparison.replace("=", "#")

        if detailed:
            content += "\n" + detailed_comparison.replace("=", "#")

        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(content)

        print(f"\n[OK] Rapport sauvegardé: {output}")

    return 0


def execute(args):
    """Exécute la commande compare-evaluations."""
    return compare_evaluations(
        files=args.files,
        names=args.names,
        detailed=args.detailed,
        output=args.output
    )


def register_compare_evaluations_command(subparsers):
    """Enregistre la commande compare-evaluations."""
    parser = subparsers.add_parser(
        'compare-evaluations',
        help='Compare plusieurs évaluations existantes'
    )

    parser.add_argument(
        'files',
        type=str,
        nargs='+',
        help='Fichiers JSON de résultats à comparer'
    )
    parser.add_argument(
        '-n', '--names',
        type=str,
        nargs='+',
        help='Noms personnalisés pour les évaluations'
    )
    parser.add_argument(
        '-d', '--detailed',
        action='store_true',
        help='Afficher comparaison question par question'
    )
    parser.add_argument(
        '-o', '--output',
        type=str,
        help='Fichier Markdown de sortie'
    )

    parser.set_defaults(func=execute)
